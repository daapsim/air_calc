﻿namespace APH_e_PV
{
    partial class Singularidades
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Singularidades));
            this.rdbtnFlangeC1 = new System.Windows.Forms.RadioButton();
            this.rdbtnRoscaC1 = new System.Windows.Forms.RadioButton();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.rdbtnUniao_C1 = new System.Windows.Forms.RadioButton();
            this.rdbtnRetencao_C1 = new System.Windows.Forms.RadioButton();
            this.rdbtnAngular_C1 = new System.Windows.Forms.RadioButton();
            this.rdbtnGlobo_C1 = new System.Windows.Forms.RadioButton();
            this.rdbtnGaveta_C1 = new System.Windows.Forms.RadioButton();
            this.rdbtnTRamal_C1 = new System.Windows.Forms.RadioButton();
            this.rdbtnTLinha_C1 = new System.Windows.Forms.RadioButton();
            this.rdbtnCurva180_C1 = new System.Windows.Forms.RadioButton();
            this.rdbtnCurva45_C1 = new System.Windows.Forms.RadioButton();
            this.rdbtnCurva90_C1 = new System.Windows.Forms.RadioButton();
            this.rdbtnCotovelo_C1 = new System.Windows.Forms.RadioButton();
            this.cboxQuant = new System.Windows.Forms.ComboBox();
            this.lblTotalC1 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.Singularidades_Princ = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.rdbtnDN11_C1 = new System.Windows.Forms.RadioButton();
            this.rdbtnDN10_C1 = new System.Windows.Forms.RadioButton();
            this.rdbtnDN9_C1 = new System.Windows.Forms.RadioButton();
            this.rdbtnDN8_C1 = new System.Windows.Forms.RadioButton();
            this.rdbtnDN7_C1 = new System.Windows.Forms.RadioButton();
            this.rdbtnDN6_C1 = new System.Windows.Forms.RadioButton();
            this.rdbtnDN5_C1 = new System.Windows.Forms.RadioButton();
            this.rdbtnDN4_C1 = new System.Windows.Forms.RadioButton();
            this.rdbtnDN3_C1 = new System.Windows.Forms.RadioButton();
            this.rdbtnDN2_C1 = new System.Windows.Forms.RadioButton();
            this.rdbtnDN_C1 = new System.Windows.Forms.RadioButton();
            this.rdbtnDN14_C1 = new System.Windows.Forms.RadioButton();
            this.rdbtnDN13_C1 = new System.Windows.Forms.RadioButton();
            this.checkC1 = new System.Windows.Forms.CheckBox();
            this.rdbtnDN12_C1 = new System.Windows.Forms.RadioButton();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.pictureBox11 = new System.Windows.Forms.PictureBox();
            this.pictureBox10 = new System.Windows.Forms.PictureBox();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.btnCalc_C1 = new System.Windows.Forms.Button();
            this.btnCalc_C2 = new System.Windows.Forms.Button();
            this.checkC2 = new System.Windows.Forms.CheckBox();
            this.lblTotalC2 = new System.Windows.Forms.Label();
            this.btnCalc_C3 = new System.Windows.Forms.Button();
            this.checkC3 = new System.Windows.Forms.CheckBox();
            this.lblTotalC3 = new System.Windows.Forms.Label();
            this.btnCalc_C4 = new System.Windows.Forms.Button();
            this.checkC4 = new System.Windows.Forms.CheckBox();
            this.lblTotalC4 = new System.Windows.Forms.Label();
            this.btnCalc_C5 = new System.Windows.Forms.Button();
            this.checkC5 = new System.Windows.Forms.CheckBox();
            this.lblTotalC5 = new System.Windows.Forms.Label();
            this.btnCalc_C6 = new System.Windows.Forms.Button();
            this.checkC6 = new System.Windows.Forms.CheckBox();
            this.lblTotalC6 = new System.Windows.Forms.Label();
            this.btnCalc_C7 = new System.Windows.Forms.Button();
            this.checkC7 = new System.Windows.Forms.CheckBox();
            this.lblTotalC7 = new System.Windows.Forms.Label();
            this.btnCalc_C8 = new System.Windows.Forms.Button();
            this.checkC8 = new System.Windows.Forms.CheckBox();
            this.lblTotalC8 = new System.Windows.Forms.Label();
            this.btnCalc_C9 = new System.Windows.Forms.Button();
            this.checkC9 = new System.Windows.Forms.CheckBox();
            this.lblTotalC9 = new System.Windows.Forms.Label();
            this.btnCalc_C10 = new System.Windows.Forms.Button();
            this.checkC10 = new System.Windows.Forms.CheckBox();
            this.lblTotalC10 = new System.Windows.Forms.Label();
            this.lblTotalPrinc = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.btnLTfim = new System.Windows.Forms.Button();
            this.btnLimpar = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // rdbtnFlangeC1
            // 
            this.rdbtnFlangeC1.AutoSize = true;
            this.rdbtnFlangeC1.BackColor = System.Drawing.Color.Aquamarine;
            this.rdbtnFlangeC1.Font = new System.Drawing.Font("Century", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbtnFlangeC1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.rdbtnFlangeC1.Location = new System.Drawing.Point(5, 31);
            this.rdbtnFlangeC1.MinimumSize = new System.Drawing.Size(90, 0);
            this.rdbtnFlangeC1.Name = "rdbtnFlangeC1";
            this.rdbtnFlangeC1.Size = new System.Drawing.Size(90, 19);
            this.rdbtnFlangeC1.TabIndex = 166;
            this.rdbtnFlangeC1.Tag = "Caract";
            this.rdbtnFlangeC1.Text = "Flangeado\r\n";
            this.rdbtnFlangeC1.UseVisualStyleBackColor = false;
            // 
            // rdbtnRoscaC1
            // 
            this.rdbtnRoscaC1.AutoSize = true;
            this.rdbtnRoscaC1.BackColor = System.Drawing.Color.Aquamarine;
            this.rdbtnRoscaC1.Font = new System.Drawing.Font("Century", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbtnRoscaC1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.rdbtnRoscaC1.Location = new System.Drawing.Point(5, 10);
            this.rdbtnRoscaC1.Name = "rdbtnRoscaC1";
            this.rdbtnRoscaC1.Size = new System.Drawing.Size(90, 19);
            this.rdbtnRoscaC1.TabIndex = 165;
            this.rdbtnRoscaC1.Tag = "Caract";
            this.rdbtnRoscaC1.Text = "Rosqueado\r\n";
            this.rdbtnRoscaC1.UseVisualStyleBackColor = false;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.LightGoldenrodYellow;
            this.label6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(1, 32);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(114, 18);
            this.label6.TabIndex = 164;
            this.label6.Text = "Tipo de Objeto";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label7.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(390, 2);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(75, 21);
            this.label7.TabIndex = 163;
            this.label7.Text = "Conexões";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Aquamarine;
            this.label3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(719, 5);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(106, 18);
            this.label3.TabIndex = 162;
            this.label3.Text = "Característica";
            // 
            // rdbtnUniao_C1
            // 
            this.rdbtnUniao_C1.AutoSize = true;
            this.rdbtnUniao_C1.BackColor = System.Drawing.Color.LightGoldenrodYellow;
            this.rdbtnUniao_C1.Font = new System.Drawing.Font("Century Gothic", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbtnUniao_C1.Location = new System.Drawing.Point(828, 13);
            this.rdbtnUniao_C1.Margin = new System.Windows.Forms.Padding(10);
            this.rdbtnUniao_C1.MinimumSize = new System.Drawing.Size(40, 40);
            this.rdbtnUniao_C1.Name = "rdbtnUniao_C1";
            this.rdbtnUniao_C1.Size = new System.Drawing.Size(92, 40);
            this.rdbtnUniao_C1.TabIndex = 161;
            this.rdbtnUniao_C1.Text = "União filtro Y";
            this.rdbtnUniao_C1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.rdbtnUniao_C1.UseVisualStyleBackColor = false;
            // 
            // rdbtnRetencao_C1
            // 
            this.rdbtnRetencao_C1.AutoSize = true;
            this.rdbtnRetencao_C1.BackColor = System.Drawing.Color.LightGoldenrodYellow;
            this.rdbtnRetencao_C1.Font = new System.Drawing.Font("Century Gothic", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbtnRetencao_C1.Location = new System.Drawing.Point(739, 13);
            this.rdbtnRetencao_C1.Margin = new System.Windows.Forms.Padding(10);
            this.rdbtnRetencao_C1.MinimumSize = new System.Drawing.Size(40, 40);
            this.rdbtnRetencao_C1.Name = "rdbtnRetencao_C1";
            this.rdbtnRetencao_C1.Size = new System.Drawing.Size(83, 40);
            this.rdbtnRetencao_C1.TabIndex = 160;
            this.rdbtnRetencao_C1.Text = "Válvula de\r\nretenção";
            this.rdbtnRetencao_C1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.rdbtnRetencao_C1.UseVisualStyleBackColor = false;
            // 
            // rdbtnAngular_C1
            // 
            this.rdbtnAngular_C1.AutoSize = true;
            this.rdbtnAngular_C1.BackColor = System.Drawing.Color.LightGoldenrodYellow;
            this.rdbtnAngular_C1.Font = new System.Drawing.Font("Century Gothic", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbtnAngular_C1.Location = new System.Drawing.Point(666, 13);
            this.rdbtnAngular_C1.Margin = new System.Windows.Forms.Padding(10);
            this.rdbtnAngular_C1.MinimumSize = new System.Drawing.Size(40, 40);
            this.rdbtnAngular_C1.Name = "rdbtnAngular_C1";
            this.rdbtnAngular_C1.Size = new System.Drawing.Size(67, 40);
            this.rdbtnAngular_C1.TabIndex = 159;
            this.rdbtnAngular_C1.Text = "Válvula\r\nangular";
            this.rdbtnAngular_C1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.rdbtnAngular_C1.UseVisualStyleBackColor = false;
            // 
            // rdbtnGlobo_C1
            // 
            this.rdbtnGlobo_C1.AutoSize = true;
            this.rdbtnGlobo_C1.BackColor = System.Drawing.Color.LightGoldenrodYellow;
            this.rdbtnGlobo_C1.Font = new System.Drawing.Font("Century Gothic", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbtnGlobo_C1.Location = new System.Drawing.Point(594, 13);
            this.rdbtnGlobo_C1.Margin = new System.Windows.Forms.Padding(10);
            this.rdbtnGlobo_C1.MinimumSize = new System.Drawing.Size(40, 40);
            this.rdbtnGlobo_C1.Name = "rdbtnGlobo_C1";
            this.rdbtnGlobo_C1.Size = new System.Drawing.Size(66, 40);
            this.rdbtnGlobo_C1.TabIndex = 158;
            this.rdbtnGlobo_C1.Text = "Válvula\r\nglobo";
            this.rdbtnGlobo_C1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.rdbtnGlobo_C1.UseVisualStyleBackColor = false;
            // 
            // rdbtnGaveta_C1
            // 
            this.rdbtnGaveta_C1.AutoSize = true;
            this.rdbtnGaveta_C1.BackColor = System.Drawing.Color.LightGoldenrodYellow;
            this.rdbtnGaveta_C1.Font = new System.Drawing.Font("Century Gothic", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbtnGaveta_C1.Location = new System.Drawing.Point(522, 13);
            this.rdbtnGaveta_C1.Margin = new System.Windows.Forms.Padding(10);
            this.rdbtnGaveta_C1.MinimumSize = new System.Drawing.Size(40, 40);
            this.rdbtnGaveta_C1.Name = "rdbtnGaveta_C1";
            this.rdbtnGaveta_C1.Size = new System.Drawing.Size(66, 40);
            this.rdbtnGaveta_C1.TabIndex = 157;
            this.rdbtnGaveta_C1.Text = "Válvula\r\ngaveta";
            this.rdbtnGaveta_C1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.rdbtnGaveta_C1.UseVisualStyleBackColor = false;
            // 
            // rdbtnTRamal_C1
            // 
            this.rdbtnTRamal_C1.AutoSize = true;
            this.rdbtnTRamal_C1.BackColor = System.Drawing.Color.LightGoldenrodYellow;
            this.rdbtnTRamal_C1.Font = new System.Drawing.Font("Century Gothic", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbtnTRamal_C1.Location = new System.Drawing.Point(432, 13);
            this.rdbtnTRamal_C1.Margin = new System.Windows.Forms.Padding(10);
            this.rdbtnTRamal_C1.MinimumSize = new System.Drawing.Size(40, 40);
            this.rdbtnTRamal_C1.Name = "rdbtnTRamal_C1";
            this.rdbtnTRamal_C1.Size = new System.Drawing.Size(84, 40);
            this.rdbtnTRamal_C1.TabIndex = 156;
            this.rdbtnTRamal_C1.Text = "Tê fluxo\r\npelo ramal";
            this.rdbtnTRamal_C1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.rdbtnTRamal_C1.UseVisualStyleBackColor = false;
            // 
            // rdbtnTLinha_C1
            // 
            this.rdbtnTLinha_C1.AutoSize = true;
            this.rdbtnTLinha_C1.BackColor = System.Drawing.Color.LightGoldenrodYellow;
            this.rdbtnTLinha_C1.Font = new System.Drawing.Font("Century Gothic", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbtnTLinha_C1.Location = new System.Drawing.Point(353, 13);
            this.rdbtnTLinha_C1.Margin = new System.Windows.Forms.Padding(10);
            this.rdbtnTLinha_C1.MinimumSize = new System.Drawing.Size(40, 40);
            this.rdbtnTLinha_C1.Name = "rdbtnTLinha_C1";
            this.rdbtnTLinha_C1.Size = new System.Drawing.Size(73, 40);
            this.rdbtnTLinha_C1.TabIndex = 155;
            this.rdbtnTLinha_C1.Text = "Tê fluxo\r\nem linha";
            this.rdbtnTLinha_C1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.rdbtnTLinha_C1.UseVisualStyleBackColor = false;
            // 
            // rdbtnCurva180_C1
            // 
            this.rdbtnCurva180_C1.AutoSize = true;
            this.rdbtnCurva180_C1.BackColor = System.Drawing.Color.LightGoldenrodYellow;
            this.rdbtnCurva180_C1.Font = new System.Drawing.Font("Century Gothic", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbtnCurva180_C1.Location = new System.Drawing.Point(264, 12);
            this.rdbtnCurva180_C1.Margin = new System.Windows.Forms.Padding(10);
            this.rdbtnCurva180_C1.MinimumSize = new System.Drawing.Size(40, 40);
            this.rdbtnCurva180_C1.Name = "rdbtnCurva180_C1";
            this.rdbtnCurva180_C1.Size = new System.Drawing.Size(83, 40);
            this.rdbtnCurva180_C1.TabIndex = 154;
            this.rdbtnCurva180_C1.Text = "Curva 180°\r\nraio longo";
            this.rdbtnCurva180_C1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.rdbtnCurva180_C1.UseVisualStyleBackColor = false;
            // 
            // rdbtnCurva45_C1
            // 
            this.rdbtnCurva45_C1.AutoSize = true;
            this.rdbtnCurva45_C1.BackColor = System.Drawing.Color.LightGoldenrodYellow;
            this.rdbtnCurva45_C1.Font = new System.Drawing.Font("Century Gothic", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbtnCurva45_C1.Location = new System.Drawing.Point(181, 12);
            this.rdbtnCurva45_C1.Margin = new System.Windows.Forms.Padding(10);
            this.rdbtnCurva45_C1.MinimumSize = new System.Drawing.Size(40, 40);
            this.rdbtnCurva45_C1.Name = "rdbtnCurva45_C1";
            this.rdbtnCurva45_C1.Size = new System.Drawing.Size(77, 40);
            this.rdbtnCurva45_C1.TabIndex = 153;
            this.rdbtnCurva45_C1.Text = "Curva 45°";
            this.rdbtnCurva45_C1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.rdbtnCurva45_C1.UseVisualStyleBackColor = false;
            // 
            // rdbtnCurva90_C1
            // 
            this.rdbtnCurva90_C1.AutoSize = true;
            this.rdbtnCurva90_C1.BackColor = System.Drawing.Color.LightGoldenrodYellow;
            this.rdbtnCurva90_C1.Font = new System.Drawing.Font("Century Gothic", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbtnCurva90_C1.Location = new System.Drawing.Point(100, 12);
            this.rdbtnCurva90_C1.Margin = new System.Windows.Forms.Padding(10);
            this.rdbtnCurva90_C1.MinimumSize = new System.Drawing.Size(40, 40);
            this.rdbtnCurva90_C1.Name = "rdbtnCurva90_C1";
            this.rdbtnCurva90_C1.Size = new System.Drawing.Size(75, 40);
            this.rdbtnCurva90_C1.TabIndex = 152;
            this.rdbtnCurva90_C1.Text = "Curva de\r\nraio 90°";
            this.rdbtnCurva90_C1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.rdbtnCurva90_C1.UseVisualStyleBackColor = false;
            // 
            // rdbtnCotovelo_C1
            // 
            this.rdbtnCotovelo_C1.AutoSize = true;
            this.rdbtnCotovelo_C1.BackColor = System.Drawing.Color.LightGoldenrodYellow;
            this.rdbtnCotovelo_C1.Font = new System.Drawing.Font("Century Gothic", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbtnCotovelo_C1.Location = new System.Drawing.Point(7, 12);
            this.rdbtnCotovelo_C1.Margin = new System.Windows.Forms.Padding(10);
            this.rdbtnCotovelo_C1.MinimumSize = new System.Drawing.Size(40, 40);
            this.rdbtnCotovelo_C1.Name = "rdbtnCotovelo_C1";
            this.rdbtnCotovelo_C1.Size = new System.Drawing.Size(87, 40);
            this.rdbtnCotovelo_C1.TabIndex = 151;
            this.rdbtnCotovelo_C1.Text = "Cotovelo \r\ncomum 90°";
            this.rdbtnCotovelo_C1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.rdbtnCotovelo_C1.UseVisualStyleBackColor = false;
            // 
            // cboxQuant
            // 
            this.cboxQuant.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboxQuant.FormattingEnabled = true;
            this.cboxQuant.Location = new System.Drawing.Point(547, 26);
            this.cboxQuant.Name = "cboxQuant";
            this.cboxQuant.Size = new System.Drawing.Size(44, 24);
            this.cboxQuant.TabIndex = 150;
            // 
            // lblTotalC1
            // 
            this.lblTotalC1.AutoSize = true;
            this.lblTotalC1.BackColor = System.Drawing.SystemColors.Control;
            this.lblTotalC1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblTotalC1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotalC1.Location = new System.Drawing.Point(32, 269);
            this.lblTotalC1.Name = "lblTotalC1";
            this.lblTotalC1.Size = new System.Drawing.Size(66, 22);
            this.lblTotalC1.TabIndex = 149;
            this.lblTotalC1.Text = "TOTAL";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Honeydew;
            this.label5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(526, 5);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(90, 18);
            this.label5.TabIndex = 148;
            this.label5.Text = "Quantidade";
            // 
            // Singularidades_Princ
            // 
            this.Singularidades_Princ.AutoSize = true;
            this.Singularidades_Princ.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Singularidades_Princ.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Singularidades_Princ.Location = new System.Drawing.Point(-2, -1);
            this.Singularidades_Princ.MinimumSize = new System.Drawing.Size(285, 0);
            this.Singularidades_Princ.Name = "Singularidades_Princ";
            this.Singularidades_Princ.Size = new System.Drawing.Size(352, 26);
            this.Singularidades_Princ.TabIndex = 147;
            this.Singularidades_Princ.Text = "Principal - Secundária - Alimentação\r\n";
            this.Singularidades_Princ.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Orange;
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(6, 164);
            this.label1.MinimumSize = new System.Drawing.Size(60, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(146, 20);
            this.label1.TabIndex = 167;
            this.label1.Text = "Diâmetro nom. (pol)\r\n";
            // 
            // rdbtnDN11_C1
            // 
            this.rdbtnDN11_C1.AutoSize = true;
            this.rdbtnDN11_C1.BackColor = System.Drawing.Color.Orange;
            this.rdbtnDN11_C1.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbtnDN11_C1.Location = new System.Drawing.Point(580, 10);
            this.rdbtnDN11_C1.Margin = new System.Windows.Forms.Padding(10);
            this.rdbtnDN11_C1.MaximumSize = new System.Drawing.Size(80, 20);
            this.rdbtnDN11_C1.MinimumSize = new System.Drawing.Size(20, 20);
            this.rdbtnDN11_C1.Name = "rdbtnDN11_C1";
            this.rdbtnDN11_C1.Size = new System.Drawing.Size(38, 20);
            this.rdbtnDN11_C1.TabIndex = 178;
            this.rdbtnDN11_C1.Text = "5\"";
            this.rdbtnDN11_C1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.rdbtnDN11_C1.UseVisualStyleBackColor = false;
            // 
            // rdbtnDN10_C1
            // 
            this.rdbtnDN10_C1.AutoSize = true;
            this.rdbtnDN10_C1.BackColor = System.Drawing.Color.Orange;
            this.rdbtnDN10_C1.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbtnDN10_C1.Location = new System.Drawing.Point(537, 10);
            this.rdbtnDN10_C1.Margin = new System.Windows.Forms.Padding(10);
            this.rdbtnDN10_C1.MaximumSize = new System.Drawing.Size(80, 20);
            this.rdbtnDN10_C1.MinimumSize = new System.Drawing.Size(20, 20);
            this.rdbtnDN10_C1.Name = "rdbtnDN10_C1";
            this.rdbtnDN10_C1.Size = new System.Drawing.Size(38, 20);
            this.rdbtnDN10_C1.TabIndex = 177;
            this.rdbtnDN10_C1.Text = "4\"\r\n";
            this.rdbtnDN10_C1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.rdbtnDN10_C1.UseVisualStyleBackColor = false;
            // 
            // rdbtnDN9_C1
            // 
            this.rdbtnDN9_C1.AutoSize = true;
            this.rdbtnDN9_C1.BackColor = System.Drawing.Color.Orange;
            this.rdbtnDN9_C1.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbtnDN9_C1.Location = new System.Drawing.Point(464, 10);
            this.rdbtnDN9_C1.Margin = new System.Windows.Forms.Padding(10);
            this.rdbtnDN9_C1.MaximumSize = new System.Drawing.Size(80, 20);
            this.rdbtnDN9_C1.MinimumSize = new System.Drawing.Size(20, 20);
            this.rdbtnDN9_C1.Name = "rdbtnDN9_C1";
            this.rdbtnDN9_C1.Size = new System.Drawing.Size(67, 20);
            this.rdbtnDN9_C1.TabIndex = 176;
            this.rdbtnDN9_C1.Text = "3\" 1/2\"";
            this.rdbtnDN9_C1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.rdbtnDN9_C1.UseVisualStyleBackColor = false;
            // 
            // rdbtnDN8_C1
            // 
            this.rdbtnDN8_C1.AutoSize = true;
            this.rdbtnDN8_C1.BackColor = System.Drawing.Color.Orange;
            this.rdbtnDN8_C1.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbtnDN8_C1.Location = new System.Drawing.Point(420, 10);
            this.rdbtnDN8_C1.Margin = new System.Windows.Forms.Padding(10);
            this.rdbtnDN8_C1.MaximumSize = new System.Drawing.Size(80, 20);
            this.rdbtnDN8_C1.MinimumSize = new System.Drawing.Size(20, 20);
            this.rdbtnDN8_C1.Name = "rdbtnDN8_C1";
            this.rdbtnDN8_C1.Size = new System.Drawing.Size(38, 20);
            this.rdbtnDN8_C1.TabIndex = 175;
            this.rdbtnDN8_C1.Text = "3\"";
            this.rdbtnDN8_C1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.rdbtnDN8_C1.UseVisualStyleBackColor = false;
            // 
            // rdbtnDN7_C1
            // 
            this.rdbtnDN7_C1.AutoSize = true;
            this.rdbtnDN7_C1.BackColor = System.Drawing.Color.Orange;
            this.rdbtnDN7_C1.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbtnDN7_C1.Location = new System.Drawing.Point(347, 10);
            this.rdbtnDN7_C1.Margin = new System.Windows.Forms.Padding(10);
            this.rdbtnDN7_C1.MaximumSize = new System.Drawing.Size(80, 20);
            this.rdbtnDN7_C1.MinimumSize = new System.Drawing.Size(20, 20);
            this.rdbtnDN7_C1.Name = "rdbtnDN7_C1";
            this.rdbtnDN7_C1.Size = new System.Drawing.Size(67, 20);
            this.rdbtnDN7_C1.TabIndex = 174;
            this.rdbtnDN7_C1.Text = "2\" 1/2\"";
            this.rdbtnDN7_C1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.rdbtnDN7_C1.UseVisualStyleBackColor = false;
            // 
            // rdbtnDN6_C1
            // 
            this.rdbtnDN6_C1.AutoSize = true;
            this.rdbtnDN6_C1.BackColor = System.Drawing.Color.Orange;
            this.rdbtnDN6_C1.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbtnDN6_C1.Location = new System.Drawing.Point(303, 10);
            this.rdbtnDN6_C1.Margin = new System.Windows.Forms.Padding(10);
            this.rdbtnDN6_C1.MaximumSize = new System.Drawing.Size(80, 20);
            this.rdbtnDN6_C1.MinimumSize = new System.Drawing.Size(20, 20);
            this.rdbtnDN6_C1.Name = "rdbtnDN6_C1";
            this.rdbtnDN6_C1.Size = new System.Drawing.Size(38, 20);
            this.rdbtnDN6_C1.TabIndex = 173;
            this.rdbtnDN6_C1.Text = "2\"";
            this.rdbtnDN6_C1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.rdbtnDN6_C1.UseVisualStyleBackColor = false;
            // 
            // rdbtnDN5_C1
            // 
            this.rdbtnDN5_C1.AutoSize = true;
            this.rdbtnDN5_C1.BackColor = System.Drawing.Color.Orange;
            this.rdbtnDN5_C1.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbtnDN5_C1.Location = new System.Drawing.Point(230, 10);
            this.rdbtnDN5_C1.Margin = new System.Windows.Forms.Padding(10);
            this.rdbtnDN5_C1.MaximumSize = new System.Drawing.Size(80, 20);
            this.rdbtnDN5_C1.MinimumSize = new System.Drawing.Size(20, 20);
            this.rdbtnDN5_C1.Name = "rdbtnDN5_C1";
            this.rdbtnDN5_C1.Size = new System.Drawing.Size(67, 20);
            this.rdbtnDN5_C1.TabIndex = 172;
            this.rdbtnDN5_C1.Text = "1\" 1/2\"";
            this.rdbtnDN5_C1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.rdbtnDN5_C1.UseVisualStyleBackColor = false;
            // 
            // rdbtnDN4_C1
            // 
            this.rdbtnDN4_C1.AutoSize = true;
            this.rdbtnDN4_C1.BackColor = System.Drawing.Color.Orange;
            this.rdbtnDN4_C1.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbtnDN4_C1.Location = new System.Drawing.Point(158, 10);
            this.rdbtnDN4_C1.Margin = new System.Windows.Forms.Padding(10);
            this.rdbtnDN4_C1.MaximumSize = new System.Drawing.Size(80, 20);
            this.rdbtnDN4_C1.MinimumSize = new System.Drawing.Size(20, 20);
            this.rdbtnDN4_C1.Name = "rdbtnDN4_C1";
            this.rdbtnDN4_C1.Size = new System.Drawing.Size(67, 20);
            this.rdbtnDN4_C1.TabIndex = 171;
            this.rdbtnDN4_C1.Text = "1\" 1/4\"";
            this.rdbtnDN4_C1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.rdbtnDN4_C1.UseVisualStyleBackColor = false;
            // 
            // rdbtnDN3_C1
            // 
            this.rdbtnDN3_C1.AutoSize = true;
            this.rdbtnDN3_C1.BackColor = System.Drawing.Color.Orange;
            this.rdbtnDN3_C1.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbtnDN3_C1.Location = new System.Drawing.Point(116, 10);
            this.rdbtnDN3_C1.Margin = new System.Windows.Forms.Padding(10);
            this.rdbtnDN3_C1.MaximumSize = new System.Drawing.Size(80, 20);
            this.rdbtnDN3_C1.MinimumSize = new System.Drawing.Size(20, 20);
            this.rdbtnDN3_C1.Name = "rdbtnDN3_C1";
            this.rdbtnDN3_C1.Size = new System.Drawing.Size(38, 20);
            this.rdbtnDN3_C1.TabIndex = 170;
            this.rdbtnDN3_C1.Text = "1\"";
            this.rdbtnDN3_C1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.rdbtnDN3_C1.UseVisualStyleBackColor = false;
            // 
            // rdbtnDN2_C1
            // 
            this.rdbtnDN2_C1.AutoSize = true;
            this.rdbtnDN2_C1.BackColor = System.Drawing.Color.Orange;
            this.rdbtnDN2_C1.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbtnDN2_C1.Location = new System.Drawing.Point(59, 10);
            this.rdbtnDN2_C1.Margin = new System.Windows.Forms.Padding(10);
            this.rdbtnDN2_C1.MaximumSize = new System.Drawing.Size(80, 20);
            this.rdbtnDN2_C1.MinimumSize = new System.Drawing.Size(20, 20);
            this.rdbtnDN2_C1.Name = "rdbtnDN2_C1";
            this.rdbtnDN2_C1.Size = new System.Drawing.Size(51, 20);
            this.rdbtnDN2_C1.TabIndex = 169;
            this.rdbtnDN2_C1.Text = "3/4\"";
            this.rdbtnDN2_C1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.rdbtnDN2_C1.UseVisualStyleBackColor = false;
            // 
            // rdbtnDN_C1
            // 
            this.rdbtnDN_C1.AutoSize = true;
            this.rdbtnDN_C1.BackColor = System.Drawing.Color.Orange;
            this.rdbtnDN_C1.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbtnDN_C1.Location = new System.Drawing.Point(3, 10);
            this.rdbtnDN_C1.Margin = new System.Windows.Forms.Padding(10);
            this.rdbtnDN_C1.MaximumSize = new System.Drawing.Size(80, 20);
            this.rdbtnDN_C1.MinimumSize = new System.Drawing.Size(20, 20);
            this.rdbtnDN_C1.Name = "rdbtnDN_C1";
            this.rdbtnDN_C1.Size = new System.Drawing.Size(51, 20);
            this.rdbtnDN_C1.TabIndex = 168;
            this.rdbtnDN_C1.Text = "1/2\"";
            this.rdbtnDN_C1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.rdbtnDN_C1.UseVisualStyleBackColor = false;
            // 
            // rdbtnDN14_C1
            // 
            this.rdbtnDN14_C1.AutoSize = true;
            this.rdbtnDN14_C1.BackColor = System.Drawing.Color.Orange;
            this.rdbtnDN14_C1.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbtnDN14_C1.Location = new System.Drawing.Point(711, 10);
            this.rdbtnDN14_C1.Margin = new System.Windows.Forms.Padding(10);
            this.rdbtnDN14_C1.MaximumSize = new System.Drawing.Size(80, 20);
            this.rdbtnDN14_C1.MinimumSize = new System.Drawing.Size(20, 20);
            this.rdbtnDN14_C1.Name = "rdbtnDN14_C1";
            this.rdbtnDN14_C1.Size = new System.Drawing.Size(45, 20);
            this.rdbtnDN14_C1.TabIndex = 180;
            this.rdbtnDN14_C1.Text = "10\"";
            this.rdbtnDN14_C1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.rdbtnDN14_C1.UseVisualStyleBackColor = false;
            // 
            // rdbtnDN13_C1
            // 
            this.rdbtnDN13_C1.AutoSize = true;
            this.rdbtnDN13_C1.BackColor = System.Drawing.Color.Orange;
            this.rdbtnDN13_C1.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbtnDN13_C1.Location = new System.Drawing.Point(667, 10);
            this.rdbtnDN13_C1.Margin = new System.Windows.Forms.Padding(10);
            this.rdbtnDN13_C1.MaximumSize = new System.Drawing.Size(80, 20);
            this.rdbtnDN13_C1.MinimumSize = new System.Drawing.Size(20, 20);
            this.rdbtnDN13_C1.Name = "rdbtnDN13_C1";
            this.rdbtnDN13_C1.Size = new System.Drawing.Size(38, 20);
            this.rdbtnDN13_C1.TabIndex = 179;
            this.rdbtnDN13_C1.Text = "8\"\r\n";
            this.rdbtnDN13_C1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.rdbtnDN13_C1.UseVisualStyleBackColor = false;
            // 
            // checkC1
            // 
            this.checkC1.AutoSize = true;
            this.checkC1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkC1.Location = new System.Drawing.Point(12, 217);
            this.checkC1.MaximumSize = new System.Drawing.Size(170, 0);
            this.checkC1.MinimumSize = new System.Drawing.Size(90, 15);
            this.checkC1.Name = "checkC1";
            this.checkC1.Size = new System.Drawing.Size(139, 20);
            this.checkC1.TabIndex = 181;
            this.checkC1.Text = "Ativar/Desativar";
            this.checkC1.UseVisualStyleBackColor = true;
            this.checkC1.CheckedChanged += new System.EventHandler(this.checkC1_CheckedChanged);
            // 
            // rdbtnDN12_C1
            // 
            this.rdbtnDN12_C1.AutoSize = true;
            this.rdbtnDN12_C1.BackColor = System.Drawing.Color.Orange;
            this.rdbtnDN12_C1.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbtnDN12_C1.Location = new System.Drawing.Point(624, 10);
            this.rdbtnDN12_C1.Margin = new System.Windows.Forms.Padding(10);
            this.rdbtnDN12_C1.MaximumSize = new System.Drawing.Size(80, 20);
            this.rdbtnDN12_C1.MinimumSize = new System.Drawing.Size(20, 20);
            this.rdbtnDN12_C1.Name = "rdbtnDN12_C1";
            this.rdbtnDN12_C1.Size = new System.Drawing.Size(38, 20);
            this.rdbtnDN12_C1.TabIndex = 182;
            this.rdbtnDN12_C1.Text = "6\"";
            this.rdbtnDN12_C1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.rdbtnDN12_C1.UseVisualStyleBackColor = false;
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.Transparent;
            this.groupBox1.Controls.Add(this.rdbtnRoscaC1);
            this.groupBox1.Controls.Add(this.rdbtnFlangeC1);
            this.groupBox1.Location = new System.Drawing.Point(825, -5);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(101, 54);
            this.groupBox1.TabIndex = 183;
            this.groupBox1.TabStop = false;
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.Transparent;
            this.groupBox2.Controls.Add(this.pictureBox11);
            this.groupBox2.Controls.Add(this.pictureBox10);
            this.groupBox2.Controls.Add(this.pictureBox9);
            this.groupBox2.Controls.Add(this.pictureBox8);
            this.groupBox2.Controls.Add(this.pictureBox7);
            this.groupBox2.Controls.Add(this.pictureBox6);
            this.groupBox2.Controls.Add(this.pictureBox5);
            this.groupBox2.Controls.Add(this.pictureBox4);
            this.groupBox2.Controls.Add(this.pictureBox3);
            this.groupBox2.Controls.Add(this.pictureBox2);
            this.groupBox2.Controls.Add(this.pictureBox1);
            this.groupBox2.Controls.Add(this.rdbtnCotovelo_C1);
            this.groupBox2.Controls.Add(this.rdbtnCurva90_C1);
            this.groupBox2.Controls.Add(this.rdbtnCurva45_C1);
            this.groupBox2.Controls.Add(this.rdbtnCurva180_C1);
            this.groupBox2.Controls.Add(this.rdbtnTLinha_C1);
            this.groupBox2.Controls.Add(this.rdbtnTRamal_C1);
            this.groupBox2.Controls.Add(this.rdbtnGaveta_C1);
            this.groupBox2.Controls.Add(this.rdbtnGlobo_C1);
            this.groupBox2.Controls.Add(this.rdbtnAngular_C1);
            this.groupBox2.Controls.Add(this.rdbtnRetencao_C1);
            this.groupBox2.Controls.Add(this.rdbtnUniao_C1);
            this.groupBox2.Location = new System.Drawing.Point(-1, 49);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(0);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(927, 106);
            this.groupBox2.TabIndex = 184;
            this.groupBox2.TabStop = false;
            // 
            // pictureBox11
            // 
            this.pictureBox11.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox11.Image")));
            this.pictureBox11.Location = new System.Drawing.Point(828, 56);
            this.pictureBox11.Name = "pictureBox11";
            this.pictureBox11.Size = new System.Drawing.Size(93, 44);
            this.pictureBox11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox11.TabIndex = 172;
            this.pictureBox11.TabStop = false;
            // 
            // pictureBox10
            // 
            this.pictureBox10.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox10.Image")));
            this.pictureBox10.Location = new System.Drawing.Point(739, 56);
            this.pictureBox10.Name = "pictureBox10";
            this.pictureBox10.Size = new System.Drawing.Size(83, 44);
            this.pictureBox10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox10.TabIndex = 171;
            this.pictureBox10.TabStop = false;
            // 
            // pictureBox9
            // 
            this.pictureBox9.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox9.Image")));
            this.pictureBox9.Location = new System.Drawing.Point(666, 56);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(68, 44);
            this.pictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox9.TabIndex = 170;
            this.pictureBox9.TabStop = false;
            // 
            // pictureBox8
            // 
            this.pictureBox8.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox8.Image")));
            this.pictureBox8.Location = new System.Drawing.Point(594, 56);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(66, 44);
            this.pictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox8.TabIndex = 169;
            this.pictureBox8.TabStop = false;
            // 
            // pictureBox7
            // 
            this.pictureBox7.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox7.Image")));
            this.pictureBox7.Location = new System.Drawing.Point(522, 56);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(66, 44);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox7.TabIndex = 168;
            this.pictureBox7.TabStop = false;
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox6.Image")));
            this.pictureBox6.Location = new System.Drawing.Point(432, 56);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(84, 44);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox6.TabIndex = 167;
            this.pictureBox6.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox5.Image")));
            this.pictureBox5.Location = new System.Drawing.Point(353, 56);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(73, 44);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox5.TabIndex = 166;
            this.pictureBox5.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(264, 56);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(83, 44);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 165;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(181, 56);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(77, 44);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 164;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(100, 56);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(75, 44);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 163;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(6, 56);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(88, 44);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 162;
            this.pictureBox1.TabStop = false;
            // 
            // groupBox3
            // 
            this.groupBox3.BackColor = System.Drawing.Color.Transparent;
            this.groupBox3.Controls.Add(this.rdbtnDN_C1);
            this.groupBox3.Controls.Add(this.rdbtnDN2_C1);
            this.groupBox3.Controls.Add(this.rdbtnDN3_C1);
            this.groupBox3.Controls.Add(this.rdbtnDN12_C1);
            this.groupBox3.Controls.Add(this.rdbtnDN4_C1);
            this.groupBox3.Controls.Add(this.rdbtnDN5_C1);
            this.groupBox3.Controls.Add(this.rdbtnDN14_C1);
            this.groupBox3.Controls.Add(this.rdbtnDN6_C1);
            this.groupBox3.Controls.Add(this.rdbtnDN13_C1);
            this.groupBox3.Controls.Add(this.rdbtnDN7_C1);
            this.groupBox3.Controls.Add(this.rdbtnDN11_C1);
            this.groupBox3.Controls.Add(this.rdbtnDN8_C1);
            this.groupBox3.Controls.Add(this.rdbtnDN10_C1);
            this.groupBox3.Controls.Add(this.rdbtnDN9_C1);
            this.groupBox3.Location = new System.Drawing.Point(158, 155);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(0);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(761, 34);
            this.groupBox3.TabIndex = 185;
            this.groupBox3.TabStop = false;
            // 
            // btnCalc_C1
            // 
            this.btnCalc_C1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCalc_C1.Location = new System.Drawing.Point(31, 243);
            this.btnCalc_C1.Name = "btnCalc_C1";
            this.btnCalc_C1.Size = new System.Drawing.Size(99, 23);
            this.btnCalc_C1.TabIndex = 186;
            this.btnCalc_C1.Text = "Calcular C1";
            this.btnCalc_C1.UseVisualStyleBackColor = true;
            this.btnCalc_C1.Click += new System.EventHandler(this.btnCalc_C1_Click);
            // 
            // btnCalc_C2
            // 
            this.btnCalc_C2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCalc_C2.Location = new System.Drawing.Point(180, 243);
            this.btnCalc_C2.Name = "btnCalc_C2";
            this.btnCalc_C2.Size = new System.Drawing.Size(99, 23);
            this.btnCalc_C2.TabIndex = 189;
            this.btnCalc_C2.Text = "Calcular C2";
            this.btnCalc_C2.UseVisualStyleBackColor = true;
            this.btnCalc_C2.Click += new System.EventHandler(this.btnCalc_C2_Click);
            // 
            // checkC2
            // 
            this.checkC2.AutoSize = true;
            this.checkC2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkC2.Location = new System.Drawing.Point(161, 217);
            this.checkC2.MaximumSize = new System.Drawing.Size(170, 0);
            this.checkC2.MinimumSize = new System.Drawing.Size(90, 15);
            this.checkC2.Name = "checkC2";
            this.checkC2.Size = new System.Drawing.Size(139, 20);
            this.checkC2.TabIndex = 188;
            this.checkC2.Text = "Ativar/Desativar";
            this.checkC2.UseVisualStyleBackColor = true;
            this.checkC2.CheckedChanged += new System.EventHandler(this.checkC2_CheckedChanged);
            // 
            // lblTotalC2
            // 
            this.lblTotalC2.AutoSize = true;
            this.lblTotalC2.BackColor = System.Drawing.SystemColors.Control;
            this.lblTotalC2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblTotalC2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotalC2.Location = new System.Drawing.Point(181, 269);
            this.lblTotalC2.Name = "lblTotalC2";
            this.lblTotalC2.Size = new System.Drawing.Size(66, 22);
            this.lblTotalC2.TabIndex = 187;
            this.lblTotalC2.Text = "TOTAL";
            // 
            // btnCalc_C3
            // 
            this.btnCalc_C3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCalc_C3.Location = new System.Drawing.Point(329, 243);
            this.btnCalc_C3.Name = "btnCalc_C3";
            this.btnCalc_C3.Size = new System.Drawing.Size(99, 23);
            this.btnCalc_C3.TabIndex = 192;
            this.btnCalc_C3.Text = "Calcular C3";
            this.btnCalc_C3.UseVisualStyleBackColor = true;
            this.btnCalc_C3.Click += new System.EventHandler(this.btnCalc_C3_Click);
            // 
            // checkC3
            // 
            this.checkC3.AutoSize = true;
            this.checkC3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkC3.Location = new System.Drawing.Point(310, 217);
            this.checkC3.MaximumSize = new System.Drawing.Size(170, 0);
            this.checkC3.MinimumSize = new System.Drawing.Size(90, 15);
            this.checkC3.Name = "checkC3";
            this.checkC3.Size = new System.Drawing.Size(139, 20);
            this.checkC3.TabIndex = 191;
            this.checkC3.Text = "Ativar/Desativar";
            this.checkC3.UseVisualStyleBackColor = true;
            this.checkC3.CheckedChanged += new System.EventHandler(this.checkC3_CheckedChanged);
            // 
            // lblTotalC3
            // 
            this.lblTotalC3.AutoSize = true;
            this.lblTotalC3.BackColor = System.Drawing.SystemColors.Control;
            this.lblTotalC3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblTotalC3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotalC3.Location = new System.Drawing.Point(330, 269);
            this.lblTotalC3.Name = "lblTotalC3";
            this.lblTotalC3.Size = new System.Drawing.Size(66, 22);
            this.lblTotalC3.TabIndex = 190;
            this.lblTotalC3.Text = "TOTAL";
            // 
            // btnCalc_C4
            // 
            this.btnCalc_C4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCalc_C4.Location = new System.Drawing.Point(480, 243);
            this.btnCalc_C4.Name = "btnCalc_C4";
            this.btnCalc_C4.Size = new System.Drawing.Size(99, 23);
            this.btnCalc_C4.TabIndex = 195;
            this.btnCalc_C4.Text = "Calcular C4";
            this.btnCalc_C4.UseVisualStyleBackColor = true;
            this.btnCalc_C4.Click += new System.EventHandler(this.btnCalc_C4_Click);
            // 
            // checkC4
            // 
            this.checkC4.AutoSize = true;
            this.checkC4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkC4.Location = new System.Drawing.Point(461, 217);
            this.checkC4.MaximumSize = new System.Drawing.Size(170, 0);
            this.checkC4.MinimumSize = new System.Drawing.Size(90, 15);
            this.checkC4.Name = "checkC4";
            this.checkC4.Size = new System.Drawing.Size(139, 20);
            this.checkC4.TabIndex = 194;
            this.checkC4.Text = "Ativar/Desativar";
            this.checkC4.UseVisualStyleBackColor = true;
            this.checkC4.CheckedChanged += new System.EventHandler(this.checkC4_CheckedChanged);
            // 
            // lblTotalC4
            // 
            this.lblTotalC4.AutoSize = true;
            this.lblTotalC4.BackColor = System.Drawing.SystemColors.Control;
            this.lblTotalC4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblTotalC4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotalC4.Location = new System.Drawing.Point(482, 269);
            this.lblTotalC4.Name = "lblTotalC4";
            this.lblTotalC4.Size = new System.Drawing.Size(66, 22);
            this.lblTotalC4.TabIndex = 193;
            this.lblTotalC4.Text = "TOTAL";
            // 
            // btnCalc_C5
            // 
            this.btnCalc_C5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCalc_C5.Location = new System.Drawing.Point(632, 243);
            this.btnCalc_C5.Name = "btnCalc_C5";
            this.btnCalc_C5.Size = new System.Drawing.Size(99, 23);
            this.btnCalc_C5.TabIndex = 198;
            this.btnCalc_C5.Text = "Calcular C5";
            this.btnCalc_C5.UseVisualStyleBackColor = true;
            this.btnCalc_C5.Click += new System.EventHandler(this.btnCalc_C5_Click);
            // 
            // checkC5
            // 
            this.checkC5.AutoSize = true;
            this.checkC5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkC5.Location = new System.Drawing.Point(613, 217);
            this.checkC5.MaximumSize = new System.Drawing.Size(170, 0);
            this.checkC5.MinimumSize = new System.Drawing.Size(90, 15);
            this.checkC5.Name = "checkC5";
            this.checkC5.Size = new System.Drawing.Size(139, 20);
            this.checkC5.TabIndex = 197;
            this.checkC5.Text = "Ativar/Desativar";
            this.checkC5.UseVisualStyleBackColor = true;
            this.checkC5.CheckedChanged += new System.EventHandler(this.checkC5_CheckedChanged);
            // 
            // lblTotalC5
            // 
            this.lblTotalC5.AutoSize = true;
            this.lblTotalC5.BackColor = System.Drawing.SystemColors.Control;
            this.lblTotalC5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblTotalC5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotalC5.Location = new System.Drawing.Point(633, 269);
            this.lblTotalC5.Name = "lblTotalC5";
            this.lblTotalC5.Size = new System.Drawing.Size(66, 22);
            this.lblTotalC5.TabIndex = 196;
            this.lblTotalC5.Text = "TOTAL";
            // 
            // btnCalc_C6
            // 
            this.btnCalc_C6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCalc_C6.Location = new System.Drawing.Point(32, 347);
            this.btnCalc_C6.Name = "btnCalc_C6";
            this.btnCalc_C6.Size = new System.Drawing.Size(99, 23);
            this.btnCalc_C6.TabIndex = 201;
            this.btnCalc_C6.Text = "Calcular C6";
            this.btnCalc_C6.UseVisualStyleBackColor = true;
            this.btnCalc_C6.Click += new System.EventHandler(this.btnCalc_C6_Click);
            // 
            // checkC6
            // 
            this.checkC6.AutoSize = true;
            this.checkC6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkC6.Location = new System.Drawing.Point(13, 321);
            this.checkC6.MaximumSize = new System.Drawing.Size(170, 0);
            this.checkC6.MinimumSize = new System.Drawing.Size(90, 15);
            this.checkC6.Name = "checkC6";
            this.checkC6.Size = new System.Drawing.Size(139, 20);
            this.checkC6.TabIndex = 200;
            this.checkC6.Text = "Ativar/Desativar";
            this.checkC6.UseVisualStyleBackColor = true;
            this.checkC6.CheckedChanged += new System.EventHandler(this.checkC6_CheckedChanged);
            // 
            // lblTotalC6
            // 
            this.lblTotalC6.AutoSize = true;
            this.lblTotalC6.BackColor = System.Drawing.SystemColors.Control;
            this.lblTotalC6.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblTotalC6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotalC6.Location = new System.Drawing.Point(33, 373);
            this.lblTotalC6.Name = "lblTotalC6";
            this.lblTotalC6.Size = new System.Drawing.Size(66, 22);
            this.lblTotalC6.TabIndex = 199;
            this.lblTotalC6.Text = "TOTAL";
            // 
            // btnCalc_C7
            // 
            this.btnCalc_C7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCalc_C7.Location = new System.Drawing.Point(180, 347);
            this.btnCalc_C7.Name = "btnCalc_C7";
            this.btnCalc_C7.Size = new System.Drawing.Size(99, 23);
            this.btnCalc_C7.TabIndex = 204;
            this.btnCalc_C7.Text = "Calcular C7";
            this.btnCalc_C7.UseVisualStyleBackColor = true;
            this.btnCalc_C7.Click += new System.EventHandler(this.btnCalc_C7_Click);
            // 
            // checkC7
            // 
            this.checkC7.AutoSize = true;
            this.checkC7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkC7.Location = new System.Drawing.Point(161, 321);
            this.checkC7.MaximumSize = new System.Drawing.Size(170, 0);
            this.checkC7.MinimumSize = new System.Drawing.Size(90, 15);
            this.checkC7.Name = "checkC7";
            this.checkC7.Size = new System.Drawing.Size(139, 20);
            this.checkC7.TabIndex = 203;
            this.checkC7.Text = "Ativar/Desativar";
            this.checkC7.UseVisualStyleBackColor = true;
            this.checkC7.CheckedChanged += new System.EventHandler(this.checkC7_CheckedChanged);
            // 
            // lblTotalC7
            // 
            this.lblTotalC7.AutoSize = true;
            this.lblTotalC7.BackColor = System.Drawing.SystemColors.Control;
            this.lblTotalC7.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblTotalC7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotalC7.Location = new System.Drawing.Point(182, 373);
            this.lblTotalC7.Name = "lblTotalC7";
            this.lblTotalC7.Size = new System.Drawing.Size(66, 22);
            this.lblTotalC7.TabIndex = 202;
            this.lblTotalC7.Text = "TOTAL";
            // 
            // btnCalc_C8
            // 
            this.btnCalc_C8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCalc_C8.Location = new System.Drawing.Point(329, 347);
            this.btnCalc_C8.Name = "btnCalc_C8";
            this.btnCalc_C8.Size = new System.Drawing.Size(99, 23);
            this.btnCalc_C8.TabIndex = 207;
            this.btnCalc_C8.Text = "Calcular C8";
            this.btnCalc_C8.UseVisualStyleBackColor = true;
            this.btnCalc_C8.Click += new System.EventHandler(this.btnCalc_C8_Click);
            // 
            // checkC8
            // 
            this.checkC8.AutoSize = true;
            this.checkC8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkC8.Location = new System.Drawing.Point(310, 321);
            this.checkC8.MaximumSize = new System.Drawing.Size(170, 0);
            this.checkC8.MinimumSize = new System.Drawing.Size(90, 15);
            this.checkC8.Name = "checkC8";
            this.checkC8.Size = new System.Drawing.Size(139, 20);
            this.checkC8.TabIndex = 206;
            this.checkC8.Text = "Ativar/Desativar";
            this.checkC8.UseVisualStyleBackColor = true;
            this.checkC8.CheckedChanged += new System.EventHandler(this.checkC8_CheckedChanged);
            // 
            // lblTotalC8
            // 
            this.lblTotalC8.AutoSize = true;
            this.lblTotalC8.BackColor = System.Drawing.SystemColors.Control;
            this.lblTotalC8.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblTotalC8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotalC8.Location = new System.Drawing.Point(331, 373);
            this.lblTotalC8.Name = "lblTotalC8";
            this.lblTotalC8.Size = new System.Drawing.Size(66, 22);
            this.lblTotalC8.TabIndex = 205;
            this.lblTotalC8.Text = "TOTAL";
            // 
            // btnCalc_C9
            // 
            this.btnCalc_C9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCalc_C9.Location = new System.Drawing.Point(480, 347);
            this.btnCalc_C9.Name = "btnCalc_C9";
            this.btnCalc_C9.Size = new System.Drawing.Size(99, 23);
            this.btnCalc_C9.TabIndex = 210;
            this.btnCalc_C9.Text = "Calcular C9";
            this.btnCalc_C9.UseVisualStyleBackColor = true;
            this.btnCalc_C9.Click += new System.EventHandler(this.btnCalc_C9_Click);
            // 
            // checkC9
            // 
            this.checkC9.AutoSize = true;
            this.checkC9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkC9.Location = new System.Drawing.Point(461, 321);
            this.checkC9.MaximumSize = new System.Drawing.Size(170, 0);
            this.checkC9.MinimumSize = new System.Drawing.Size(90, 15);
            this.checkC9.Name = "checkC9";
            this.checkC9.Size = new System.Drawing.Size(139, 20);
            this.checkC9.TabIndex = 209;
            this.checkC9.Text = "Ativar/Desativar";
            this.checkC9.UseVisualStyleBackColor = true;
            this.checkC9.CheckedChanged += new System.EventHandler(this.checkC9_CheckedChanged);
            // 
            // lblTotalC9
            // 
            this.lblTotalC9.AutoSize = true;
            this.lblTotalC9.BackColor = System.Drawing.SystemColors.Control;
            this.lblTotalC9.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblTotalC9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotalC9.Location = new System.Drawing.Point(481, 373);
            this.lblTotalC9.Name = "lblTotalC9";
            this.lblTotalC9.Size = new System.Drawing.Size(66, 22);
            this.lblTotalC9.TabIndex = 208;
            this.lblTotalC9.Text = "TOTAL";
            // 
            // btnCalc_C10
            // 
            this.btnCalc_C10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCalc_C10.Location = new System.Drawing.Point(632, 347);
            this.btnCalc_C10.Name = "btnCalc_C10";
            this.btnCalc_C10.Size = new System.Drawing.Size(110, 23);
            this.btnCalc_C10.TabIndex = 213;
            this.btnCalc_C10.Text = "Calcular C10";
            this.btnCalc_C10.UseVisualStyleBackColor = true;
            this.btnCalc_C10.Click += new System.EventHandler(this.btnCalc_C10_Click);
            // 
            // checkC10
            // 
            this.checkC10.AutoSize = true;
            this.checkC10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkC10.Location = new System.Drawing.Point(613, 321);
            this.checkC10.MaximumSize = new System.Drawing.Size(170, 0);
            this.checkC10.MinimumSize = new System.Drawing.Size(90, 15);
            this.checkC10.Name = "checkC10";
            this.checkC10.Size = new System.Drawing.Size(139, 20);
            this.checkC10.TabIndex = 212;
            this.checkC10.Text = "Ativar/Desativar";
            this.checkC10.UseVisualStyleBackColor = true;
            this.checkC10.CheckedChanged += new System.EventHandler(this.checkC10_CheckedChanged);
            // 
            // lblTotalC10
            // 
            this.lblTotalC10.AutoSize = true;
            this.lblTotalC10.BackColor = System.Drawing.SystemColors.Control;
            this.lblTotalC10.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblTotalC10.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotalC10.Location = new System.Drawing.Point(633, 373);
            this.lblTotalC10.Name = "lblTotalC10";
            this.lblTotalC10.Size = new System.Drawing.Size(66, 22);
            this.lblTotalC10.TabIndex = 211;
            this.lblTotalC10.Text = "TOTAL";
            // 
            // lblTotalPrinc
            // 
            this.lblTotalPrinc.AutoSize = true;
            this.lblTotalPrinc.BackColor = System.Drawing.Color.Silver;
            this.lblTotalPrinc.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblTotalPrinc.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotalPrinc.ForeColor = System.Drawing.Color.Red;
            this.lblTotalPrinc.Location = new System.Drawing.Point(778, 245);
            this.lblTotalPrinc.MaximumSize = new System.Drawing.Size(120, 28);
            this.lblTotalPrinc.Name = "lblTotalPrinc";
            this.lblTotalPrinc.Size = new System.Drawing.Size(74, 25);
            this.lblTotalPrinc.TabIndex = 214;
            this.lblTotalPrinc.Text = "Lt Final";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(778, 217);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(103, 24);
            this.label16.TabIndex = 215;
            this.label16.Text = "Resultado";
            // 
            // btnLTfim
            // 
            this.btnLTfim.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLTfim.Location = new System.Drawing.Point(778, 272);
            this.btnLTfim.Name = "btnLTfim";
            this.btnLTfim.Size = new System.Drawing.Size(110, 46);
            this.btnLTfim.TabIndex = 216;
            this.btnLTfim.Text = "Calcular / Atualizar";
            this.btnLTfim.UseVisualStyleBackColor = true;
            this.btnLTfim.Click += new System.EventHandler(this.btnLTfim_Click);
            // 
            // btnLimpar
            // 
            this.btnLimpar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLimpar.Location = new System.Drawing.Point(778, 321);
            this.btnLimpar.Name = "btnLimpar";
            this.btnLimpar.Size = new System.Drawing.Size(110, 46);
            this.btnLimpar.TabIndex = 217;
            this.btnLimpar.Text = "Limpar";
            this.btnLimpar.UseVisualStyleBackColor = true;
            this.btnLimpar.Click += new System.EventHandler(this.btnLimpar_Click);
            // 
            // Singularidades
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(943, 419);
            this.Controls.Add(this.btnLimpar);
            this.Controls.Add(this.btnLTfim);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.lblTotalPrinc);
            this.Controls.Add(this.btnCalc_C10);
            this.Controls.Add(this.checkC10);
            this.Controls.Add(this.lblTotalC10);
            this.Controls.Add(this.btnCalc_C9);
            this.Controls.Add(this.checkC9);
            this.Controls.Add(this.lblTotalC9);
            this.Controls.Add(this.btnCalc_C8);
            this.Controls.Add(this.checkC8);
            this.Controls.Add(this.lblTotalC8);
            this.Controls.Add(this.btnCalc_C7);
            this.Controls.Add(this.checkC7);
            this.Controls.Add(this.lblTotalC7);
            this.Controls.Add(this.btnCalc_C6);
            this.Controls.Add(this.checkC6);
            this.Controls.Add(this.lblTotalC6);
            this.Controls.Add(this.btnCalc_C5);
            this.Controls.Add(this.checkC5);
            this.Controls.Add(this.lblTotalC5);
            this.Controls.Add(this.btnCalc_C4);
            this.Controls.Add(this.checkC4);
            this.Controls.Add(this.lblTotalC4);
            this.Controls.Add(this.btnCalc_C3);
            this.Controls.Add(this.checkC3);
            this.Controls.Add(this.lblTotalC3);
            this.Controls.Add(this.btnCalc_C2);
            this.Controls.Add(this.checkC2);
            this.Controls.Add(this.lblTotalC2);
            this.Controls.Add(this.btnCalc_C1);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.checkC1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.cboxQuant);
            this.Controls.Add(this.lblTotalC1);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.Singularidades_Princ);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "Singularidades";
            this.Text = "Singularidades";
            this.Load += new System.EventHandler(this.Singularidades_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RadioButton rdbtnFlangeC1;
        private System.Windows.Forms.RadioButton rdbtnRoscaC1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.RadioButton rdbtnUniao_C1;
        private System.Windows.Forms.RadioButton rdbtnRetencao_C1;
        private System.Windows.Forms.RadioButton rdbtnAngular_C1;
        private System.Windows.Forms.RadioButton rdbtnGlobo_C1;
        private System.Windows.Forms.RadioButton rdbtnGaveta_C1;
        private System.Windows.Forms.RadioButton rdbtnTRamal_C1;
        private System.Windows.Forms.RadioButton rdbtnTLinha_C1;
        private System.Windows.Forms.RadioButton rdbtnCurva180_C1;
        private System.Windows.Forms.RadioButton rdbtnCurva45_C1;
        private System.Windows.Forms.RadioButton rdbtnCurva90_C1;
        private System.Windows.Forms.RadioButton rdbtnCotovelo_C1;
        private System.Windows.Forms.ComboBox cboxQuant;
        private System.Windows.Forms.Label lblTotalC1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label Singularidades_Princ;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RadioButton rdbtnDN11_C1;
        private System.Windows.Forms.RadioButton rdbtnDN10_C1;
        private System.Windows.Forms.RadioButton rdbtnDN9_C1;
        private System.Windows.Forms.RadioButton rdbtnDN8_C1;
        private System.Windows.Forms.RadioButton rdbtnDN7_C1;
        private System.Windows.Forms.RadioButton rdbtnDN6_C1;
        private System.Windows.Forms.RadioButton rdbtnDN5_C1;
        private System.Windows.Forms.RadioButton rdbtnDN4_C1;
        private System.Windows.Forms.RadioButton rdbtnDN3_C1;
        private System.Windows.Forms.RadioButton rdbtnDN2_C1;
        private System.Windows.Forms.RadioButton rdbtnDN_C1;
        private System.Windows.Forms.RadioButton rdbtnDN14_C1;
        private System.Windows.Forms.RadioButton rdbtnDN13_C1;
        private System.Windows.Forms.CheckBox checkC1;
        private System.Windows.Forms.RadioButton rdbtnDN12_C1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button btnCalc_C1;
        private System.Windows.Forms.PictureBox pictureBox11;
        private System.Windows.Forms.PictureBox pictureBox10;
        private System.Windows.Forms.PictureBox pictureBox9;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button btnCalc_C2;
        private System.Windows.Forms.CheckBox checkC2;
        private System.Windows.Forms.Label lblTotalC2;
        private System.Windows.Forms.Button btnCalc_C3;
        private System.Windows.Forms.CheckBox checkC3;
        private System.Windows.Forms.Label lblTotalC3;
        private System.Windows.Forms.Button btnCalc_C4;
        private System.Windows.Forms.CheckBox checkC4;
        private System.Windows.Forms.Label lblTotalC4;
        private System.Windows.Forms.Button btnCalc_C5;
        private System.Windows.Forms.CheckBox checkC5;
        private System.Windows.Forms.Label lblTotalC5;
        private System.Windows.Forms.Button btnCalc_C6;
        private System.Windows.Forms.CheckBox checkC6;
        private System.Windows.Forms.Label lblTotalC6;
        private System.Windows.Forms.Button btnCalc_C7;
        private System.Windows.Forms.CheckBox checkC7;
        private System.Windows.Forms.Label lblTotalC7;
        private System.Windows.Forms.Button btnCalc_C8;
        private System.Windows.Forms.CheckBox checkC8;
        private System.Windows.Forms.Label lblTotalC8;
        private System.Windows.Forms.Button btnCalc_C9;
        private System.Windows.Forms.CheckBox checkC9;
        private System.Windows.Forms.Label lblTotalC9;
        private System.Windows.Forms.Button btnCalc_C10;
        private System.Windows.Forms.CheckBox checkC10;
        private System.Windows.Forms.Label lblTotalC10;
        private System.Windows.Forms.Label lblTotalPrinc;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Button btnLTfim;
        private System.Windows.Forms.Button btnLimpar;
    }
}