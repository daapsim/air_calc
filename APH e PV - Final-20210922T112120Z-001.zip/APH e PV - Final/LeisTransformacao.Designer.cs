﻿namespace APH_e_PV
{
    partial class CalculadoraTrans
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CalculadoraTrans));
            this.label1 = new System.Windows.Forms.Label();
            this.lblTer = new System.Windows.Forms.Label();
            this.lblP1Ter = new System.Windows.Forms.Label();
            this.txtP1Ter = new System.Windows.Forms.TextBox();
            this.lblV1Ter = new System.Windows.Forms.Label();
            this.txtV1Ter = new System.Windows.Forms.TextBox();
            this.lblP2Ter = new System.Windows.Forms.Label();
            this.txtP2Ter = new System.Windows.Forms.TextBox();
            this.lblV2Ter = new System.Windows.Forms.Label();
            this.txtV2Ter = new System.Windows.Forms.TextBox();
            this.btnCalcTer1 = new System.Windows.Forms.Button();
            this.lblVol = new System.Windows.Forms.Label();
            this.lblP1Vol = new System.Windows.Forms.Label();
            this.txtP1Vol = new System.Windows.Forms.TextBox();
            this.lblT1Vol = new System.Windows.Forms.Label();
            this.txtT1Vol = new System.Windows.Forms.TextBox();
            this.lblP2Vol = new System.Windows.Forms.Label();
            this.txtP2Vol = new System.Windows.Forms.TextBox();
            this.lblT2Vol = new System.Windows.Forms.Label();
            this.txtT2Vol = new System.Windows.Forms.TextBox();
            this.btnCalcVol1 = new System.Windows.Forms.Button();
            this.lblBar = new System.Windows.Forms.Label();
            this.lblV1Bar = new System.Windows.Forms.Label();
            this.txtV1Bar = new System.Windows.Forms.TextBox();
            this.lblT1Bar = new System.Windows.Forms.Label();
            this.txtT1Bar = new System.Windows.Forms.TextBox();
            this.lblV2Bar = new System.Windows.Forms.Label();
            this.txtV2Bar = new System.Windows.Forms.TextBox();
            this.lblT2Bar = new System.Windows.Forms.Label();
            this.txtT2Bar = new System.Windows.Forms.TextBox();
            this.btnCalcBar = new System.Windows.Forms.Button();
            this.lblGases = new System.Windows.Forms.Label();
            this.lblP1Gases = new System.Windows.Forms.Label();
            this.txtP1Gases = new System.Windows.Forms.TextBox();
            this.lblV1Gases = new System.Windows.Forms.Label();
            this.txtV1Gases = new System.Windows.Forms.TextBox();
            this.lblP2Gases = new System.Windows.Forms.Label();
            this.txtP2Gases = new System.Windows.Forms.TextBox();
            this.lblV2Gases = new System.Windows.Forms.Label();
            this.txtV2Gases = new System.Windows.Forms.TextBox();
            this.btnCalcGases = new System.Windows.Forms.Button();
            this.lblT1Gases = new System.Windows.Forms.Label();
            this.txtT1Gases = new System.Windows.Forms.TextBox();
            this.lblT2Gases = new System.Windows.Forms.Label();
            this.txtT2Gases = new System.Windows.Forms.TextBox();
            this.btnCalcTer2 = new System.Windows.Forms.Button();
            this.btnCalcTer3 = new System.Windows.Forms.Button();
            this.btnCalcTer4 = new System.Windows.Forms.Button();
            this.Orientador1 = new System.Windows.Forms.Label();
            this.btnCalcVol2 = new System.Windows.Forms.Button();
            this.btnCalcVol3 = new System.Windows.Forms.Button();
            this.btnCalcVol4 = new System.Windows.Forms.Button();
            this.Instrução = new System.Windows.Forms.Label();
            this.btnCalcBar2 = new System.Windows.Forms.Button();
            this.btnCalcBar3 = new System.Windows.Forms.Button();
            this.btnCalcBar4 = new System.Windows.Forms.Button();
            this.Orientador4 = new System.Windows.Forms.Label();
            this.Instrução4 = new System.Windows.Forms.Label();
            this.btnCalcGases2 = new System.Windows.Forms.Button();
            this.btnCalcGases3 = new System.Windows.Forms.Button();
            this.btnCalcGases4 = new System.Windows.Forms.Button();
            this.btnCalcGases5 = new System.Windows.Forms.Button();
            this.btnCalcGases6 = new System.Windows.Forms.Button();
            this.Leis = new System.Windows.Forms.Panel();
            this.Leis.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Silver;
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label1.Location = new System.Drawing.Point(0, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(225, 26);
            this.label1.TabIndex = 0;
            this.label1.Text = "Leis de Transformação";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblTer
            // 
            this.lblTer.AutoSize = true;
            this.lblTer.BackColor = System.Drawing.Color.Silver;
            this.lblTer.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTer.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblTer.Location = new System.Drawing.Point(1, 35);
            this.lblTer.Name = "lblTer";
            this.lblTer.Size = new System.Drawing.Size(120, 25);
            this.lblTer.TabIndex = 1;
            this.lblTer.Text = "Isotérmica";
            // 
            // lblP1Ter
            // 
            this.lblP1Ter.AutoSize = true;
            this.lblP1Ter.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblP1Ter.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblP1Ter.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblP1Ter.ForeColor = System.Drawing.Color.Red;
            this.lblP1Ter.Location = new System.Drawing.Point(6, 62);
            this.lblP1Ter.MaximumSize = new System.Drawing.Size(115, 30);
            this.lblP1Ter.Name = "lblP1Ter";
            this.lblP1Ter.Size = new System.Drawing.Size(26, 17);
            this.lblP1Ter.TabIndex = 5;
            this.lblP1Ter.Text = "P1";
            // 
            // txtP1Ter
            // 
            this.txtP1Ter.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtP1Ter.Location = new System.Drawing.Point(6, 82);
            this.txtP1Ter.MaxLength = 6;
            this.txtP1Ter.Name = "txtP1Ter";
            this.txtP1Ter.Size = new System.Drawing.Size(71, 22);
            this.txtP1Ter.TabIndex = 6;
            this.txtP1Ter.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtP1Ter.Click += new System.EventHandler(this.txtP1Ter_Click_1);
            // 
            // lblV1Ter
            // 
            this.lblV1Ter.AutoSize = true;
            this.lblV1Ter.BackColor = System.Drawing.SystemColors.Control;
            this.lblV1Ter.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblV1Ter.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblV1Ter.ForeColor = System.Drawing.Color.Red;
            this.lblV1Ter.Location = new System.Drawing.Point(130, 62);
            this.lblV1Ter.MaximumSize = new System.Drawing.Size(115, 30);
            this.lblV1Ter.Name = "lblV1Ter";
            this.lblV1Ter.Size = new System.Drawing.Size(25, 17);
            this.lblV1Ter.TabIndex = 7;
            this.lblV1Ter.Text = "V1";
            // 
            // txtV1Ter
            // 
            this.txtV1Ter.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtV1Ter.Location = new System.Drawing.Point(130, 82);
            this.txtV1Ter.MaxLength = 6;
            this.txtV1Ter.Name = "txtV1Ter";
            this.txtV1Ter.Size = new System.Drawing.Size(70, 22);
            this.txtV1Ter.TabIndex = 8;
            this.txtV1Ter.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtV1Ter.Click += new System.EventHandler(this.txtV1Ter_Click);
            // 
            // lblP2Ter
            // 
            this.lblP2Ter.AutoSize = true;
            this.lblP2Ter.BackColor = System.Drawing.SystemColors.Control;
            this.lblP2Ter.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblP2Ter.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblP2Ter.ForeColor = System.Drawing.Color.Red;
            this.lblP2Ter.Location = new System.Drawing.Point(253, 62);
            this.lblP2Ter.MaximumSize = new System.Drawing.Size(115, 30);
            this.lblP2Ter.Name = "lblP2Ter";
            this.lblP2Ter.Size = new System.Drawing.Size(26, 17);
            this.lblP2Ter.TabIndex = 9;
            this.lblP2Ter.Text = "P2";
            // 
            // txtP2Ter
            // 
            this.txtP2Ter.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtP2Ter.Location = new System.Drawing.Point(253, 82);
            this.txtP2Ter.MaxLength = 6;
            this.txtP2Ter.Name = "txtP2Ter";
            this.txtP2Ter.Size = new System.Drawing.Size(74, 22);
            this.txtP2Ter.TabIndex = 10;
            this.txtP2Ter.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtP2Ter.Click += new System.EventHandler(this.txtP2Ter_Click);
            // 
            // lblV2Ter
            // 
            this.lblV2Ter.AutoSize = true;
            this.lblV2Ter.BackColor = System.Drawing.SystemColors.Control;
            this.lblV2Ter.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblV2Ter.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblV2Ter.ForeColor = System.Drawing.Color.Red;
            this.lblV2Ter.Location = new System.Drawing.Point(375, 62);
            this.lblV2Ter.Name = "lblV2Ter";
            this.lblV2Ter.Size = new System.Drawing.Size(25, 17);
            this.lblV2Ter.TabIndex = 11;
            this.lblV2Ter.Text = "V2";
            // 
            // txtV2Ter
            // 
            this.txtV2Ter.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtV2Ter.Location = new System.Drawing.Point(375, 82);
            this.txtV2Ter.MaxLength = 6;
            this.txtV2Ter.Name = "txtV2Ter";
            this.txtV2Ter.Size = new System.Drawing.Size(72, 22);
            this.txtV2Ter.TabIndex = 12;
            this.txtV2Ter.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtV2Ter.Click += new System.EventHandler(this.txtV2Ter_Click);
            // 
            // btnCalcTer1
            // 
            this.btnCalcTer1.BackColor = System.Drawing.Color.Transparent;
            this.btnCalcTer1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCalcTer1.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnCalcTer1.FlatAppearance.BorderSize = 0;
            this.btnCalcTer1.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnCalcTer1.FlatAppearance.MouseDownBackColor = System.Drawing.SystemColors.Highlight;
            this.btnCalcTer1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnCalcTer1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCalcTer1.ForeColor = System.Drawing.Color.Transparent;
            this.btnCalcTer1.Image = ((System.Drawing.Image)(resources.GetObject("btnCalcTer1.Image")));
            this.btnCalcTer1.Location = new System.Drawing.Point(6, 104);
            this.btnCalcTer1.Name = "btnCalcTer1";
            this.btnCalcTer1.Size = new System.Drawing.Size(71, 23);
            this.btnCalcTer1.TabIndex = 41;
            this.btnCalcTer1.UseVisualStyleBackColor = false;
            this.btnCalcTer1.Click += new System.EventHandler(this.btnCalcTer1_Click);
            // 
            // lblVol
            // 
            this.lblVol.AutoSize = true;
            this.lblVol.BackColor = System.Drawing.Color.Silver;
            this.lblVol.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblVol.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblVol.Location = new System.Drawing.Point(3, 132);
            this.lblVol.Name = "lblVol";
            this.lblVol.Size = new System.Drawing.Size(118, 18);
            this.lblVol.TabIndex = 42;
            this.lblVol.Text = "Isovolumétrica";
            // 
            // lblP1Vol
            // 
            this.lblP1Vol.AutoSize = true;
            this.lblP1Vol.BackColor = System.Drawing.SystemColors.Control;
            this.lblP1Vol.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblP1Vol.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblP1Vol.ForeColor = System.Drawing.Color.Red;
            this.lblP1Vol.Location = new System.Drawing.Point(6, 155);
            this.lblP1Vol.MaximumSize = new System.Drawing.Size(115, 30);
            this.lblP1Vol.Name = "lblP1Vol";
            this.lblP1Vol.Size = new System.Drawing.Size(26, 17);
            this.lblP1Vol.TabIndex = 43;
            this.lblP1Vol.Text = "P1";
            // 
            // txtP1Vol
            // 
            this.txtP1Vol.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtP1Vol.Location = new System.Drawing.Point(6, 174);
            this.txtP1Vol.MaxLength = 6;
            this.txtP1Vol.Name = "txtP1Vol";
            this.txtP1Vol.Size = new System.Drawing.Size(71, 22);
            this.txtP1Vol.TabIndex = 44;
            this.txtP1Vol.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtP1Vol.Click += new System.EventHandler(this.txtP1Vol_Click);
            // 
            // lblT1Vol
            // 
            this.lblT1Vol.AutoSize = true;
            this.lblT1Vol.BackColor = System.Drawing.SystemColors.Control;
            this.lblT1Vol.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblT1Vol.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblT1Vol.ForeColor = System.Drawing.Color.Red;
            this.lblT1Vol.Location = new System.Drawing.Point(129, 156);
            this.lblT1Vol.MaximumSize = new System.Drawing.Size(115, 30);
            this.lblT1Vol.Name = "lblT1Vol";
            this.lblT1Vol.Size = new System.Drawing.Size(25, 17);
            this.lblT1Vol.TabIndex = 45;
            this.lblT1Vol.Text = "T1";
            // 
            // txtT1Vol
            // 
            this.txtT1Vol.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtT1Vol.Location = new System.Drawing.Point(129, 175);
            this.txtT1Vol.MaxLength = 6;
            this.txtT1Vol.Name = "txtT1Vol";
            this.txtT1Vol.Size = new System.Drawing.Size(70, 22);
            this.txtT1Vol.TabIndex = 46;
            this.txtT1Vol.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtT1Vol.Click += new System.EventHandler(this.txtT1Vol_Click);
            // 
            // lblP2Vol
            // 
            this.lblP2Vol.AutoSize = true;
            this.lblP2Vol.BackColor = System.Drawing.SystemColors.Control;
            this.lblP2Vol.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblP2Vol.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblP2Vol.ForeColor = System.Drawing.Color.Red;
            this.lblP2Vol.Location = new System.Drawing.Point(253, 158);
            this.lblP2Vol.MaximumSize = new System.Drawing.Size(115, 30);
            this.lblP2Vol.Name = "lblP2Vol";
            this.lblP2Vol.Size = new System.Drawing.Size(26, 17);
            this.lblP2Vol.TabIndex = 47;
            this.lblP2Vol.Text = "P2";
            // 
            // txtP2Vol
            // 
            this.txtP2Vol.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtP2Vol.Location = new System.Drawing.Point(253, 177);
            this.txtP2Vol.MaxLength = 6;
            this.txtP2Vol.Name = "txtP2Vol";
            this.txtP2Vol.Size = new System.Drawing.Size(71, 22);
            this.txtP2Vol.TabIndex = 48;
            this.txtP2Vol.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtP2Vol.Click += new System.EventHandler(this.txtP2Vol_Click);
            // 
            // lblT2Vol
            // 
            this.lblT2Vol.AutoSize = true;
            this.lblT2Vol.BackColor = System.Drawing.SystemColors.Control;
            this.lblT2Vol.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblT2Vol.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblT2Vol.ForeColor = System.Drawing.Color.Red;
            this.lblT2Vol.Location = new System.Drawing.Point(375, 157);
            this.lblT2Vol.Name = "lblT2Vol";
            this.lblT2Vol.Size = new System.Drawing.Size(25, 17);
            this.lblT2Vol.TabIndex = 49;
            this.lblT2Vol.Text = "T2";
            // 
            // txtT2Vol
            // 
            this.txtT2Vol.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtT2Vol.Location = new System.Drawing.Point(375, 176);
            this.txtT2Vol.MaxLength = 6;
            this.txtT2Vol.Name = "txtT2Vol";
            this.txtT2Vol.Size = new System.Drawing.Size(71, 22);
            this.txtT2Vol.TabIndex = 50;
            this.txtT2Vol.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtT2Vol.Click += new System.EventHandler(this.txtT2Vol_Click);
            // 
            // btnCalcVol1
            // 
            this.btnCalcVol1.BackColor = System.Drawing.Color.Transparent;
            this.btnCalcVol1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCalcVol1.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnCalcVol1.FlatAppearance.BorderSize = 0;
            this.btnCalcVol1.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnCalcVol1.FlatAppearance.MouseDownBackColor = System.Drawing.SystemColors.Highlight;
            this.btnCalcVol1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnCalcVol1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCalcVol1.ForeColor = System.Drawing.Color.Transparent;
            this.btnCalcVol1.Image = ((System.Drawing.Image)(resources.GetObject("btnCalcVol1.Image")));
            this.btnCalcVol1.Location = new System.Drawing.Point(4, 196);
            this.btnCalcVol1.Name = "btnCalcVol1";
            this.btnCalcVol1.Size = new System.Drawing.Size(71, 23);
            this.btnCalcVol1.TabIndex = 51;
            this.btnCalcVol1.UseVisualStyleBackColor = false;
            this.btnCalcVol1.Click += new System.EventHandler(this.btnCalcVol1_Click);
            // 
            // lblBar
            // 
            this.lblBar.AutoSize = true;
            this.lblBar.BackColor = System.Drawing.Color.Silver;
            this.lblBar.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBar.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblBar.Location = new System.Drawing.Point(1, 222);
            this.lblBar.Name = "lblBar";
            this.lblBar.Size = new System.Drawing.Size(108, 25);
            this.lblBar.TabIndex = 52;
            this.lblBar.Text = "Isobárica";
            // 
            // lblV1Bar
            // 
            this.lblV1Bar.AutoSize = true;
            this.lblV1Bar.BackColor = System.Drawing.SystemColors.Control;
            this.lblV1Bar.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblV1Bar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblV1Bar.ForeColor = System.Drawing.Color.Red;
            this.lblV1Bar.Location = new System.Drawing.Point(6, 253);
            this.lblV1Bar.MaximumSize = new System.Drawing.Size(115, 30);
            this.lblV1Bar.Name = "lblV1Bar";
            this.lblV1Bar.Size = new System.Drawing.Size(25, 17);
            this.lblV1Bar.TabIndex = 53;
            this.lblV1Bar.Text = "V1";
            // 
            // txtV1Bar
            // 
            this.txtV1Bar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtV1Bar.Location = new System.Drawing.Point(6, 271);
            this.txtV1Bar.MaxLength = 6;
            this.txtV1Bar.Name = "txtV1Bar";
            this.txtV1Bar.Size = new System.Drawing.Size(68, 22);
            this.txtV1Bar.TabIndex = 54;
            this.txtV1Bar.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtV1Bar.Click += new System.EventHandler(this.txtV1Bar_Click);
            // 
            // lblT1Bar
            // 
            this.lblT1Bar.AutoSize = true;
            this.lblT1Bar.BackColor = System.Drawing.SystemColors.Control;
            this.lblT1Bar.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblT1Bar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblT1Bar.ForeColor = System.Drawing.Color.Red;
            this.lblT1Bar.Location = new System.Drawing.Point(130, 253);
            this.lblT1Bar.MaximumSize = new System.Drawing.Size(115, 30);
            this.lblT1Bar.Name = "lblT1Bar";
            this.lblT1Bar.Size = new System.Drawing.Size(25, 17);
            this.lblT1Bar.TabIndex = 55;
            this.lblT1Bar.Text = "T1";
            // 
            // txtT1Bar
            // 
            this.txtT1Bar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtT1Bar.Location = new System.Drawing.Point(130, 272);
            this.txtT1Bar.MaxLength = 6;
            this.txtT1Bar.Name = "txtT1Bar";
            this.txtT1Bar.Size = new System.Drawing.Size(71, 22);
            this.txtT1Bar.TabIndex = 56;
            this.txtT1Bar.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtT1Bar.Click += new System.EventHandler(this.txtT1Bar_Click);
            // 
            // lblV2Bar
            // 
            this.lblV2Bar.AutoSize = true;
            this.lblV2Bar.BackColor = System.Drawing.SystemColors.Control;
            this.lblV2Bar.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblV2Bar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblV2Bar.ForeColor = System.Drawing.Color.Red;
            this.lblV2Bar.Location = new System.Drawing.Point(253, 253);
            this.lblV2Bar.MaximumSize = new System.Drawing.Size(115, 30);
            this.lblV2Bar.Name = "lblV2Bar";
            this.lblV2Bar.Size = new System.Drawing.Size(25, 17);
            this.lblV2Bar.TabIndex = 57;
            this.lblV2Bar.Text = "V2";
            // 
            // txtV2Bar
            // 
            this.txtV2Bar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtV2Bar.Location = new System.Drawing.Point(253, 272);
            this.txtV2Bar.MaxLength = 6;
            this.txtV2Bar.Name = "txtV2Bar";
            this.txtV2Bar.Size = new System.Drawing.Size(69, 22);
            this.txtV2Bar.TabIndex = 58;
            this.txtV2Bar.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtV2Bar.Click += new System.EventHandler(this.txtV2Bar_Click);
            // 
            // lblT2Bar
            // 
            this.lblT2Bar.AutoSize = true;
            this.lblT2Bar.BackColor = System.Drawing.SystemColors.Control;
            this.lblT2Bar.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblT2Bar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblT2Bar.ForeColor = System.Drawing.Color.Red;
            this.lblT2Bar.Location = new System.Drawing.Point(375, 252);
            this.lblT2Bar.Name = "lblT2Bar";
            this.lblT2Bar.Size = new System.Drawing.Size(25, 17);
            this.lblT2Bar.TabIndex = 59;
            this.lblT2Bar.Text = "T2";
            // 
            // txtT2Bar
            // 
            this.txtT2Bar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtT2Bar.Location = new System.Drawing.Point(376, 272);
            this.txtT2Bar.MaxLength = 6;
            this.txtT2Bar.Name = "txtT2Bar";
            this.txtT2Bar.Size = new System.Drawing.Size(71, 22);
            this.txtT2Bar.TabIndex = 60;
            this.txtT2Bar.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtT2Bar.Click += new System.EventHandler(this.txtT2Bar_Click);
            // 
            // btnCalcBar
            // 
            this.btnCalcBar.BackColor = System.Drawing.Color.Transparent;
            this.btnCalcBar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCalcBar.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnCalcBar.FlatAppearance.BorderSize = 0;
            this.btnCalcBar.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnCalcBar.FlatAppearance.MouseDownBackColor = System.Drawing.SystemColors.Highlight;
            this.btnCalcBar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnCalcBar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCalcBar.ForeColor = System.Drawing.Color.Transparent;
            this.btnCalcBar.Image = ((System.Drawing.Image)(resources.GetObject("btnCalcBar.Image")));
            this.btnCalcBar.Location = new System.Drawing.Point(4, 294);
            this.btnCalcBar.Name = "btnCalcBar";
            this.btnCalcBar.Size = new System.Drawing.Size(71, 23);
            this.btnCalcBar.TabIndex = 61;
            this.btnCalcBar.UseVisualStyleBackColor = false;
            this.btnCalcBar.Click += new System.EventHandler(this.btnCalcBar_Click);
            // 
            // lblGases
            // 
            this.lblGases.AutoSize = true;
            this.lblGases.BackColor = System.Drawing.Color.Silver;
            this.lblGases.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGases.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblGases.Location = new System.Drawing.Point(2, 330);
            this.lblGases.Name = "lblGases";
            this.lblGases.Size = new System.Drawing.Size(115, 20);
            this.lblGases.TabIndex = 62;
            this.lblGases.Text = "Gases Ideais";
            // 
            // lblP1Gases
            // 
            this.lblP1Gases.AutoSize = true;
            this.lblP1Gases.BackColor = System.Drawing.SystemColors.Control;
            this.lblP1Gases.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblP1Gases.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblP1Gases.Location = new System.Drawing.Point(4, 355);
            this.lblP1Gases.MaximumSize = new System.Drawing.Size(107, 20);
            this.lblP1Gases.Name = "lblP1Gases";
            this.lblP1Gases.Size = new System.Drawing.Size(24, 15);
            this.lblP1Gases.TabIndex = 63;
            this.lblP1Gases.Text = "P1";
            // 
            // txtP1Gases
            // 
            this.txtP1Gases.Location = new System.Drawing.Point(6, 373);
            this.txtP1Gases.MaxLength = 5;
            this.txtP1Gases.Name = "txtP1Gases";
            this.txtP1Gases.Size = new System.Drawing.Size(53, 20);
            this.txtP1Gases.TabIndex = 64;
            this.txtP1Gases.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtP1Gases.Click += new System.EventHandler(this.txtP1Gases_Click);
            // 
            // lblV1Gases
            // 
            this.lblV1Gases.AutoSize = true;
            this.lblV1Gases.BackColor = System.Drawing.SystemColors.Control;
            this.lblV1Gases.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblV1Gases.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblV1Gases.Location = new System.Drawing.Point(83, 355);
            this.lblV1Gases.MaximumSize = new System.Drawing.Size(107, 20);
            this.lblV1Gases.Name = "lblV1Gases";
            this.lblV1Gases.Size = new System.Drawing.Size(24, 15);
            this.lblV1Gases.TabIndex = 65;
            this.lblV1Gases.Text = "V1";
            // 
            // txtV1Gases
            // 
            this.txtV1Gases.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtV1Gases.Location = new System.Drawing.Point(85, 373);
            this.txtV1Gases.MaxLength = 5;
            this.txtV1Gases.Name = "txtV1Gases";
            this.txtV1Gases.Size = new System.Drawing.Size(52, 21);
            this.txtV1Gases.TabIndex = 66;
            this.txtV1Gases.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtV1Gases.Click += new System.EventHandler(this.txtV1Gases_Click);
            // 
            // lblP2Gases
            // 
            this.lblP2Gases.AutoSize = true;
            this.lblP2Gases.BackColor = System.Drawing.SystemColors.Control;
            this.lblP2Gases.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblP2Gases.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblP2Gases.Location = new System.Drawing.Point(242, 355);
            this.lblP2Gases.MaximumSize = new System.Drawing.Size(107, 20);
            this.lblP2Gases.Name = "lblP2Gases";
            this.lblP2Gases.Size = new System.Drawing.Size(24, 15);
            this.lblP2Gases.TabIndex = 67;
            this.lblP2Gases.Text = "P2";
            // 
            // txtP2Gases
            // 
            this.txtP2Gases.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtP2Gases.Location = new System.Drawing.Point(244, 373);
            this.txtP2Gases.MaxLength = 5;
            this.txtP2Gases.Name = "txtP2Gases";
            this.txtP2Gases.Size = new System.Drawing.Size(51, 21);
            this.txtP2Gases.TabIndex = 68;
            this.txtP2Gases.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtP2Gases.Click += new System.EventHandler(this.txtP2Gases_Click);
            // 
            // lblV2Gases
            // 
            this.lblV2Gases.AutoSize = true;
            this.lblV2Gases.BackColor = System.Drawing.SystemColors.Control;
            this.lblV2Gases.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblV2Gases.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblV2Gases.Location = new System.Drawing.Point(321, 355);
            this.lblV2Gases.MaximumSize = new System.Drawing.Size(107, 20);
            this.lblV2Gases.Name = "lblV2Gases";
            this.lblV2Gases.Size = new System.Drawing.Size(24, 15);
            this.lblV2Gases.TabIndex = 69;
            this.lblV2Gases.Text = "V2";
            // 
            // txtV2Gases
            // 
            this.txtV2Gases.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtV2Gases.Location = new System.Drawing.Point(323, 373);
            this.txtV2Gases.MaxLength = 5;
            this.txtV2Gases.Name = "txtV2Gases";
            this.txtV2Gases.Size = new System.Drawing.Size(53, 21);
            this.txtV2Gases.TabIndex = 70;
            this.txtV2Gases.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtV2Gases.Click += new System.EventHandler(this.txtV2Gases_Click);
            // 
            // btnCalcGases
            // 
            this.btnCalcGases.BackColor = System.Drawing.Color.Transparent;
            this.btnCalcGases.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCalcGases.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnCalcGases.FlatAppearance.BorderSize = 0;
            this.btnCalcGases.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnCalcGases.FlatAppearance.MouseDownBackColor = System.Drawing.SystemColors.Highlight;
            this.btnCalcGases.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnCalcGases.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCalcGases.ForeColor = System.Drawing.Color.Transparent;
            this.btnCalcGases.Image = ((System.Drawing.Image)(resources.GetObject("btnCalcGases.Image")));
            this.btnCalcGases.Location = new System.Drawing.Point(5, 395);
            this.btnCalcGases.Name = "btnCalcGases";
            this.btnCalcGases.Size = new System.Drawing.Size(70, 21);
            this.btnCalcGases.TabIndex = 71;
            this.btnCalcGases.UseVisualStyleBackColor = false;
            this.btnCalcGases.Click += new System.EventHandler(this.btnCalcGases_Click);
            // 
            // lblT1Gases
            // 
            this.lblT1Gases.AutoSize = true;
            this.lblT1Gases.BackColor = System.Drawing.SystemColors.Control;
            this.lblT1Gases.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblT1Gases.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblT1Gases.Location = new System.Drawing.Point(163, 355);
            this.lblT1Gases.MaximumSize = new System.Drawing.Size(107, 20);
            this.lblT1Gases.Name = "lblT1Gases";
            this.lblT1Gases.Size = new System.Drawing.Size(24, 15);
            this.lblT1Gases.TabIndex = 72;
            this.lblT1Gases.Text = "T1";
            // 
            // txtT1Gases
            // 
            this.txtT1Gases.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtT1Gases.Location = new System.Drawing.Point(165, 373);
            this.txtT1Gases.MaxLength = 5;
            this.txtT1Gases.Name = "txtT1Gases";
            this.txtT1Gases.Size = new System.Drawing.Size(53, 21);
            this.txtT1Gases.TabIndex = 73;
            this.txtT1Gases.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtT1Gases.Click += new System.EventHandler(this.txtT1Gases_Click);
            // 
            // lblT2Gases
            // 
            this.lblT2Gases.AutoSize = true;
            this.lblT2Gases.BackColor = System.Drawing.SystemColors.Control;
            this.lblT2Gases.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblT2Gases.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblT2Gases.Location = new System.Drawing.Point(400, 355);
            this.lblT2Gases.MaximumSize = new System.Drawing.Size(107, 20);
            this.lblT2Gases.Name = "lblT2Gases";
            this.lblT2Gases.Size = new System.Drawing.Size(24, 15);
            this.lblT2Gases.TabIndex = 65;
            this.lblT2Gases.Text = "T2";
            // 
            // txtT2Gases
            // 
            this.txtT2Gases.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtT2Gases.Location = new System.Drawing.Point(402, 372);
            this.txtT2Gases.MaxLength = 5;
            this.txtT2Gases.Name = "txtT2Gases";
            this.txtT2Gases.Size = new System.Drawing.Size(53, 21);
            this.txtT2Gases.TabIndex = 66;
            this.txtT2Gases.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtT2Gases.Click += new System.EventHandler(this.txtT2Gases_Click);
            // 
            // btnCalcTer2
            // 
            this.btnCalcTer2.BackColor = System.Drawing.Color.Transparent;
            this.btnCalcTer2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCalcTer2.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnCalcTer2.FlatAppearance.BorderSize = 0;
            this.btnCalcTer2.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnCalcTer2.FlatAppearance.MouseDownBackColor = System.Drawing.SystemColors.Highlight;
            this.btnCalcTer2.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnCalcTer2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCalcTer2.ForeColor = System.Drawing.Color.Transparent;
            this.btnCalcTer2.Image = ((System.Drawing.Image)(resources.GetObject("btnCalcTer2.Image")));
            this.btnCalcTer2.Location = new System.Drawing.Point(130, 104);
            this.btnCalcTer2.Name = "btnCalcTer2";
            this.btnCalcTer2.Size = new System.Drawing.Size(70, 23);
            this.btnCalcTer2.TabIndex = 74;
            this.btnCalcTer2.UseVisualStyleBackColor = false;
            this.btnCalcTer2.Click += new System.EventHandler(this.btnCalcTer2_Click);
            // 
            // btnCalcTer3
            // 
            this.btnCalcTer3.BackColor = System.Drawing.Color.Transparent;
            this.btnCalcTer3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCalcTer3.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnCalcTer3.FlatAppearance.BorderSize = 0;
            this.btnCalcTer3.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnCalcTer3.FlatAppearance.MouseDownBackColor = System.Drawing.SystemColors.Highlight;
            this.btnCalcTer3.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnCalcTer3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCalcTer3.ForeColor = System.Drawing.Color.Transparent;
            this.btnCalcTer3.Image = ((System.Drawing.Image)(resources.GetObject("btnCalcTer3.Image")));
            this.btnCalcTer3.Location = new System.Drawing.Point(253, 104);
            this.btnCalcTer3.Name = "btnCalcTer3";
            this.btnCalcTer3.Size = new System.Drawing.Size(74, 23);
            this.btnCalcTer3.TabIndex = 75;
            this.btnCalcTer3.UseVisualStyleBackColor = false;
            this.btnCalcTer3.Click += new System.EventHandler(this.btnCalcTer3_Click);
            // 
            // btnCalcTer4
            // 
            this.btnCalcTer4.BackColor = System.Drawing.Color.Transparent;
            this.btnCalcTer4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCalcTer4.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnCalcTer4.FlatAppearance.BorderSize = 0;
            this.btnCalcTer4.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnCalcTer4.FlatAppearance.MouseDownBackColor = System.Drawing.SystemColors.Highlight;
            this.btnCalcTer4.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnCalcTer4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCalcTer4.ForeColor = System.Drawing.Color.Transparent;
            this.btnCalcTer4.Image = ((System.Drawing.Image)(resources.GetObject("btnCalcTer4.Image")));
            this.btnCalcTer4.Location = new System.Drawing.Point(376, 104);
            this.btnCalcTer4.Name = "btnCalcTer4";
            this.btnCalcTer4.Size = new System.Drawing.Size(72, 23);
            this.btnCalcTer4.TabIndex = 76;
            this.btnCalcTer4.UseVisualStyleBackColor = false;
            this.btnCalcTer4.Click += new System.EventHandler(this.btnCalcTer4_Click);
            // 
            // Orientador1
            // 
            this.Orientador1.AutoSize = true;
            this.Orientador1.BackColor = System.Drawing.Color.Gold;
            this.Orientador1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Orientador1.Location = new System.Drawing.Point(231, 4);
            this.Orientador1.Name = "Orientador1";
            this.Orientador1.Size = new System.Drawing.Size(100, 40);
            this.Orientador1.TabIndex = 77;
            this.Orientador1.Text = "Forneça\r\n3 variáveis*";
            // 
            // btnCalcVol2
            // 
            this.btnCalcVol2.BackColor = System.Drawing.Color.Transparent;
            this.btnCalcVol2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCalcVol2.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnCalcVol2.FlatAppearance.BorderSize = 0;
            this.btnCalcVol2.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnCalcVol2.FlatAppearance.MouseDownBackColor = System.Drawing.SystemColors.Highlight;
            this.btnCalcVol2.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnCalcVol2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCalcVol2.ForeColor = System.Drawing.Color.Transparent;
            this.btnCalcVol2.Image = ((System.Drawing.Image)(resources.GetObject("btnCalcVol2.Image")));
            this.btnCalcVol2.Location = new System.Drawing.Point(129, 197);
            this.btnCalcVol2.Name = "btnCalcVol2";
            this.btnCalcVol2.Size = new System.Drawing.Size(71, 23);
            this.btnCalcVol2.TabIndex = 78;
            this.btnCalcVol2.UseVisualStyleBackColor = false;
            this.btnCalcVol2.Click += new System.EventHandler(this.btnCalcVol2_Click);
            // 
            // btnCalcVol3
            // 
            this.btnCalcVol3.BackColor = System.Drawing.Color.Transparent;
            this.btnCalcVol3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCalcVol3.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnCalcVol3.FlatAppearance.BorderSize = 0;
            this.btnCalcVol3.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnCalcVol3.FlatAppearance.MouseDownBackColor = System.Drawing.SystemColors.Highlight;
            this.btnCalcVol3.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnCalcVol3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCalcVol3.ForeColor = System.Drawing.Color.Transparent;
            this.btnCalcVol3.Image = ((System.Drawing.Image)(resources.GetObject("btnCalcVol3.Image")));
            this.btnCalcVol3.Location = new System.Drawing.Point(253, 198);
            this.btnCalcVol3.Name = "btnCalcVol3";
            this.btnCalcVol3.Size = new System.Drawing.Size(71, 23);
            this.btnCalcVol3.TabIndex = 79;
            this.btnCalcVol3.UseVisualStyleBackColor = false;
            this.btnCalcVol3.Click += new System.EventHandler(this.btnCalcVol3_Click);
            // 
            // btnCalcVol4
            // 
            this.btnCalcVol4.BackColor = System.Drawing.Color.Transparent;
            this.btnCalcVol4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCalcVol4.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnCalcVol4.FlatAppearance.BorderSize = 0;
            this.btnCalcVol4.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnCalcVol4.FlatAppearance.MouseDownBackColor = System.Drawing.SystemColors.Highlight;
            this.btnCalcVol4.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnCalcVol4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCalcVol4.ForeColor = System.Drawing.Color.Transparent;
            this.btnCalcVol4.Image = ((System.Drawing.Image)(resources.GetObject("btnCalcVol4.Image")));
            this.btnCalcVol4.Location = new System.Drawing.Point(375, 198);
            this.btnCalcVol4.Name = "btnCalcVol4";
            this.btnCalcVol4.Size = new System.Drawing.Size(71, 23);
            this.btnCalcVol4.TabIndex = 80;
            this.btnCalcVol4.UseVisualStyleBackColor = false;
            this.btnCalcVol4.Click += new System.EventHandler(this.btnCalcVol4_Click);
            // 
            // Instrução
            // 
            this.Instrução.AutoSize = true;
            this.Instrução.BackColor = System.Drawing.SystemColors.ControlText;
            this.Instrução.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Instrução.ForeColor = System.Drawing.Color.White;
            this.Instrução.Location = new System.Drawing.Point(337, 9);
            this.Instrução.Name = "Instrução";
            this.Instrução.Size = new System.Drawing.Size(133, 26);
            this.Instrução.TabIndex = 83;
            this.Instrução.Text = "Campo vazio para a \r\nvariável desconhecida\r\n";
            // 
            // btnCalcBar2
            // 
            this.btnCalcBar2.BackColor = System.Drawing.Color.Transparent;
            this.btnCalcBar2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCalcBar2.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnCalcBar2.FlatAppearance.BorderSize = 0;
            this.btnCalcBar2.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnCalcBar2.FlatAppearance.MouseDownBackColor = System.Drawing.SystemColors.Highlight;
            this.btnCalcBar2.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnCalcBar2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCalcBar2.ForeColor = System.Drawing.Color.Transparent;
            this.btnCalcBar2.Image = ((System.Drawing.Image)(resources.GetObject("btnCalcBar2.Image")));
            this.btnCalcBar2.Location = new System.Drawing.Point(129, 295);
            this.btnCalcBar2.Name = "btnCalcBar2";
            this.btnCalcBar2.Size = new System.Drawing.Size(71, 23);
            this.btnCalcBar2.TabIndex = 86;
            this.btnCalcBar2.UseVisualStyleBackColor = false;
            this.btnCalcBar2.Click += new System.EventHandler(this.btnCalcBar2_Click);
            // 
            // btnCalcBar3
            // 
            this.btnCalcBar3.BackColor = System.Drawing.Color.Transparent;
            this.btnCalcBar3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCalcBar3.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnCalcBar3.FlatAppearance.BorderSize = 0;
            this.btnCalcBar3.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnCalcBar3.FlatAppearance.MouseDownBackColor = System.Drawing.SystemColors.Highlight;
            this.btnCalcBar3.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnCalcBar3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCalcBar3.ForeColor = System.Drawing.Color.Transparent;
            this.btnCalcBar3.Image = ((System.Drawing.Image)(resources.GetObject("btnCalcBar3.Image")));
            this.btnCalcBar3.Location = new System.Drawing.Point(253, 295);
            this.btnCalcBar3.Name = "btnCalcBar3";
            this.btnCalcBar3.Size = new System.Drawing.Size(71, 23);
            this.btnCalcBar3.TabIndex = 87;
            this.btnCalcBar3.UseVisualStyleBackColor = false;
            this.btnCalcBar3.Click += new System.EventHandler(this.btnCalcBar3_Click);
            // 
            // btnCalcBar4
            // 
            this.btnCalcBar4.BackColor = System.Drawing.Color.Transparent;
            this.btnCalcBar4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCalcBar4.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnCalcBar4.FlatAppearance.BorderSize = 0;
            this.btnCalcBar4.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnCalcBar4.FlatAppearance.MouseDownBackColor = System.Drawing.SystemColors.Highlight;
            this.btnCalcBar4.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnCalcBar4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCalcBar4.ForeColor = System.Drawing.Color.Transparent;
            this.btnCalcBar4.Image = ((System.Drawing.Image)(resources.GetObject("btnCalcBar4.Image")));
            this.btnCalcBar4.Location = new System.Drawing.Point(375, 295);
            this.btnCalcBar4.Name = "btnCalcBar4";
            this.btnCalcBar4.Size = new System.Drawing.Size(71, 23);
            this.btnCalcBar4.TabIndex = 88;
            this.btnCalcBar4.UseVisualStyleBackColor = false;
            this.btnCalcBar4.Click += new System.EventHandler(this.btnCalcBar4_Click);
            // 
            // Orientador4
            // 
            this.Orientador4.AutoSize = true;
            this.Orientador4.BackColor = System.Drawing.Color.Gold;
            this.Orientador4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Orientador4.Location = new System.Drawing.Point(133, 330);
            this.Orientador4.Name = "Orientador4";
            this.Orientador4.Size = new System.Drawing.Size(171, 20);
            this.Orientador4.TabIndex = 89;
            this.Orientador4.Text = "Forneça 5 variáveis*";
            // 
            // Instrução4
            // 
            this.Instrução4.AutoSize = true;
            this.Instrução4.BackColor = System.Drawing.SystemColors.ControlText;
            this.Instrução4.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Instrução4.ForeColor = System.Drawing.Color.White;
            this.Instrução4.Location = new System.Drawing.Point(339, 324);
            this.Instrução4.Name = "Instrução4";
            this.Instrução4.Size = new System.Drawing.Size(133, 26);
            this.Instrução4.TabIndex = 90;
            this.Instrução4.Text = "Campo vazio para a\r\nvariável desconhecida\r\n";
            // 
            // btnCalcGases2
            // 
            this.btnCalcGases2.BackColor = System.Drawing.Color.Transparent;
            this.btnCalcGases2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCalcGases2.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnCalcGases2.FlatAppearance.BorderSize = 0;
            this.btnCalcGases2.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnCalcGases2.FlatAppearance.MouseDownBackColor = System.Drawing.SystemColors.Highlight;
            this.btnCalcGases2.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnCalcGases2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCalcGases2.ForeColor = System.Drawing.Color.Transparent;
            this.btnCalcGases2.Image = ((System.Drawing.Image)(resources.GetObject("btnCalcGases2.Image")));
            this.btnCalcGases2.Location = new System.Drawing.Point(85, 395);
            this.btnCalcGases2.Name = "btnCalcGases2";
            this.btnCalcGases2.Size = new System.Drawing.Size(70, 21);
            this.btnCalcGases2.TabIndex = 91;
            this.btnCalcGases2.UseVisualStyleBackColor = false;
            this.btnCalcGases2.Click += new System.EventHandler(this.btnCalcGases2_Click);
            // 
            // btnCalcGases3
            // 
            this.btnCalcGases3.BackColor = System.Drawing.Color.Transparent;
            this.btnCalcGases3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCalcGases3.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnCalcGases3.FlatAppearance.BorderSize = 0;
            this.btnCalcGases3.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnCalcGases3.FlatAppearance.MouseDownBackColor = System.Drawing.SystemColors.Highlight;
            this.btnCalcGases3.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnCalcGases3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCalcGases3.ForeColor = System.Drawing.Color.Transparent;
            this.btnCalcGases3.Image = ((System.Drawing.Image)(resources.GetObject("btnCalcGases3.Image")));
            this.btnCalcGases3.Location = new System.Drawing.Point(163, 395);
            this.btnCalcGases3.Name = "btnCalcGases3";
            this.btnCalcGases3.Size = new System.Drawing.Size(70, 21);
            this.btnCalcGases3.TabIndex = 92;
            this.btnCalcGases3.UseVisualStyleBackColor = false;
            this.btnCalcGases3.Click += new System.EventHandler(this.btnCalcGases3_Click);
            // 
            // btnCalcGases4
            // 
            this.btnCalcGases4.BackColor = System.Drawing.Color.Transparent;
            this.btnCalcGases4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCalcGases4.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnCalcGases4.FlatAppearance.BorderSize = 0;
            this.btnCalcGases4.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnCalcGases4.FlatAppearance.MouseDownBackColor = System.Drawing.SystemColors.Highlight;
            this.btnCalcGases4.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnCalcGases4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCalcGases4.ForeColor = System.Drawing.Color.Transparent;
            this.btnCalcGases4.Image = ((System.Drawing.Image)(resources.GetObject("btnCalcGases4.Image")));
            this.btnCalcGases4.Location = new System.Drawing.Point(242, 395);
            this.btnCalcGases4.Name = "btnCalcGases4";
            this.btnCalcGases4.Size = new System.Drawing.Size(69, 21);
            this.btnCalcGases4.TabIndex = 93;
            this.btnCalcGases4.UseVisualStyleBackColor = false;
            this.btnCalcGases4.Click += new System.EventHandler(this.btnCalcGases4_Click);
            // 
            // btnCalcGases5
            // 
            this.btnCalcGases5.BackColor = System.Drawing.Color.Transparent;
            this.btnCalcGases5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCalcGases5.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnCalcGases5.FlatAppearance.BorderSize = 0;
            this.btnCalcGases5.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnCalcGases5.FlatAppearance.MouseDownBackColor = System.Drawing.SystemColors.Highlight;
            this.btnCalcGases5.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnCalcGases5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCalcGases5.ForeColor = System.Drawing.Color.Transparent;
            this.btnCalcGases5.Image = ((System.Drawing.Image)(resources.GetObject("btnCalcGases5.Image")));
            this.btnCalcGases5.Location = new System.Drawing.Point(321, 395);
            this.btnCalcGases5.Name = "btnCalcGases5";
            this.btnCalcGases5.Size = new System.Drawing.Size(69, 21);
            this.btnCalcGases5.TabIndex = 94;
            this.btnCalcGases5.UseVisualStyleBackColor = false;
            this.btnCalcGases5.Click += new System.EventHandler(this.btnCalcGases5_Click);
            // 
            // btnCalcGases6
            // 
            this.btnCalcGases6.BackColor = System.Drawing.Color.Transparent;
            this.btnCalcGases6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCalcGases6.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnCalcGases6.FlatAppearance.BorderSize = 0;
            this.btnCalcGases6.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnCalcGases6.FlatAppearance.MouseDownBackColor = System.Drawing.SystemColors.Highlight;
            this.btnCalcGases6.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnCalcGases6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCalcGases6.ForeColor = System.Drawing.Color.Transparent;
            this.btnCalcGases6.Image = ((System.Drawing.Image)(resources.GetObject("btnCalcGases6.Image")));
            this.btnCalcGases6.Location = new System.Drawing.Point(400, 395);
            this.btnCalcGases6.Name = "btnCalcGases6";
            this.btnCalcGases6.Size = new System.Drawing.Size(71, 21);
            this.btnCalcGases6.TabIndex = 95;
            this.btnCalcGases6.UseVisualStyleBackColor = false;
            this.btnCalcGases6.Click += new System.EventHandler(this.btnCalcGases6_Click);
            // 
            // Leis
            // 
            this.Leis.BackColor = System.Drawing.Color.Transparent;
            this.Leis.Controls.Add(this.btnCalcGases6);
            this.Leis.Controls.Add(this.btnCalcGases5);
            this.Leis.Controls.Add(this.btnCalcGases4);
            this.Leis.Controls.Add(this.btnCalcGases3);
            this.Leis.Controls.Add(this.btnCalcGases2);
            this.Leis.Controls.Add(this.Instrução4);
            this.Leis.Controls.Add(this.Orientador4);
            this.Leis.Controls.Add(this.btnCalcBar4);
            this.Leis.Controls.Add(this.btnCalcBar3);
            this.Leis.Controls.Add(this.btnCalcBar2);
            this.Leis.Controls.Add(this.Instrução);
            this.Leis.Controls.Add(this.btnCalcVol4);
            this.Leis.Controls.Add(this.btnCalcVol3);
            this.Leis.Controls.Add(this.btnCalcVol2);
            this.Leis.Controls.Add(this.Orientador1);
            this.Leis.Controls.Add(this.btnCalcTer4);
            this.Leis.Controls.Add(this.btnCalcTer3);
            this.Leis.Controls.Add(this.btnCalcTer2);
            this.Leis.Controls.Add(this.txtT2Gases);
            this.Leis.Controls.Add(this.lblT2Gases);
            this.Leis.Controls.Add(this.txtT1Gases);
            this.Leis.Controls.Add(this.lblT1Gases);
            this.Leis.Controls.Add(this.btnCalcGases);
            this.Leis.Controls.Add(this.txtV2Gases);
            this.Leis.Controls.Add(this.lblV2Gases);
            this.Leis.Controls.Add(this.txtP2Gases);
            this.Leis.Controls.Add(this.lblP2Gases);
            this.Leis.Controls.Add(this.txtV1Gases);
            this.Leis.Controls.Add(this.lblV1Gases);
            this.Leis.Controls.Add(this.txtP1Gases);
            this.Leis.Controls.Add(this.lblP1Gases);
            this.Leis.Controls.Add(this.lblGases);
            this.Leis.Controls.Add(this.btnCalcBar);
            this.Leis.Controls.Add(this.txtT2Bar);
            this.Leis.Controls.Add(this.lblT2Bar);
            this.Leis.Controls.Add(this.txtV2Bar);
            this.Leis.Controls.Add(this.lblV2Bar);
            this.Leis.Controls.Add(this.txtT1Bar);
            this.Leis.Controls.Add(this.lblT1Bar);
            this.Leis.Controls.Add(this.txtV1Bar);
            this.Leis.Controls.Add(this.lblV1Bar);
            this.Leis.Controls.Add(this.lblBar);
            this.Leis.Controls.Add(this.btnCalcVol1);
            this.Leis.Controls.Add(this.txtT2Vol);
            this.Leis.Controls.Add(this.lblT2Vol);
            this.Leis.Controls.Add(this.txtP2Vol);
            this.Leis.Controls.Add(this.lblP2Vol);
            this.Leis.Controls.Add(this.txtT1Vol);
            this.Leis.Controls.Add(this.lblT1Vol);
            this.Leis.Controls.Add(this.txtP1Vol);
            this.Leis.Controls.Add(this.lblP1Vol);
            this.Leis.Controls.Add(this.lblVol);
            this.Leis.Controls.Add(this.btnCalcTer1);
            this.Leis.Controls.Add(this.txtV2Ter);
            this.Leis.Controls.Add(this.lblV2Ter);
            this.Leis.Controls.Add(this.txtP2Ter);
            this.Leis.Controls.Add(this.lblP2Ter);
            this.Leis.Controls.Add(this.txtV1Ter);
            this.Leis.Controls.Add(this.lblV1Ter);
            this.Leis.Controls.Add(this.txtP1Ter);
            this.Leis.Controls.Add(this.lblP1Ter);
            this.Leis.Controls.Add(this.lblTer);
            this.Leis.Controls.Add(this.label1);
            this.Leis.Location = new System.Drawing.Point(2, 2);
            this.Leis.Name = "Leis";
            this.Leis.Size = new System.Drawing.Size(505, 427);
            this.Leis.TabIndex = 0;
            // 
            // CalculadoraTrans
            // 
            this.AcceptButton = this.btnCalcTer1;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(500, 430);
            this.Controls.Add(this.Leis);
            this.DataBindings.Add(new System.Windows.Forms.Binding("Text", global::APH_e_PV.Properties.Settings.Default, "erro", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "CalculadoraTrans";
            this.Text = global::APH_e_PV.Properties.Settings.Default.erro;
            this.Leis.ResumeLayout(false);
            this.Leis.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblTer;
        private System.Windows.Forms.Label lblP1Ter;
        private System.Windows.Forms.TextBox txtP1Ter;
        private System.Windows.Forms.Label lblV1Ter;
        private System.Windows.Forms.TextBox txtV1Ter;
        private System.Windows.Forms.Label lblP2Ter;
        private System.Windows.Forms.TextBox txtP2Ter;
        private System.Windows.Forms.Label lblV2Ter;
        private System.Windows.Forms.TextBox txtV2Ter;
        private System.Windows.Forms.Button btnCalcTer1;
        private System.Windows.Forms.Label lblVol;
        private System.Windows.Forms.Label lblP1Vol;
        private System.Windows.Forms.TextBox txtP1Vol;
        private System.Windows.Forms.Label lblT1Vol;
        private System.Windows.Forms.TextBox txtT1Vol;
        private System.Windows.Forms.Label lblP2Vol;
        private System.Windows.Forms.TextBox txtP2Vol;
        private System.Windows.Forms.Label lblT2Vol;
        private System.Windows.Forms.TextBox txtT2Vol;
        private System.Windows.Forms.Button btnCalcVol1;
        private System.Windows.Forms.Label lblBar;
        private System.Windows.Forms.Label lblV1Bar;
        private System.Windows.Forms.TextBox txtV1Bar;
        private System.Windows.Forms.Label lblT1Bar;
        private System.Windows.Forms.TextBox txtT1Bar;
        private System.Windows.Forms.Label lblV2Bar;
        private System.Windows.Forms.TextBox txtV2Bar;
        private System.Windows.Forms.Label lblT2Bar;
        private System.Windows.Forms.TextBox txtT2Bar;
        private System.Windows.Forms.Button btnCalcBar;
        private System.Windows.Forms.Label lblGases;
        private System.Windows.Forms.Label lblP1Gases;
        private System.Windows.Forms.TextBox txtP1Gases;
        private System.Windows.Forms.Label lblV1Gases;
        private System.Windows.Forms.TextBox txtV1Gases;
        private System.Windows.Forms.Label lblP2Gases;
        private System.Windows.Forms.TextBox txtP2Gases;
        private System.Windows.Forms.Label lblV2Gases;
        private System.Windows.Forms.TextBox txtV2Gases;
        private System.Windows.Forms.Button btnCalcGases;
        private System.Windows.Forms.Label lblT1Gases;
        private System.Windows.Forms.TextBox txtT1Gases;
        private System.Windows.Forms.Label lblT2Gases;
        private System.Windows.Forms.TextBox txtT2Gases;
        private System.Windows.Forms.Button btnCalcTer2;
        private System.Windows.Forms.Button btnCalcTer3;
        private System.Windows.Forms.Button btnCalcTer4;
        private System.Windows.Forms.Label Orientador1;
        private System.Windows.Forms.Button btnCalcVol2;
        private System.Windows.Forms.Button btnCalcVol3;
        private System.Windows.Forms.Button btnCalcVol4;
        private System.Windows.Forms.Label Instrução;
        private System.Windows.Forms.Button btnCalcBar2;
        private System.Windows.Forms.Button btnCalcBar3;
        private System.Windows.Forms.Button btnCalcBar4;
        private System.Windows.Forms.Label Orientador4;
        private System.Windows.Forms.Label Instrução4;
        private System.Windows.Forms.Button btnCalcGases2;
        private System.Windows.Forms.Button btnCalcGases3;
        private System.Windows.Forms.Button btnCalcGases4;
        private System.Windows.Forms.Button btnCalcGases5;
        private System.Windows.Forms.Button btnCalcGases6;
        private System.Windows.Forms.Panel Leis;
    }
}

