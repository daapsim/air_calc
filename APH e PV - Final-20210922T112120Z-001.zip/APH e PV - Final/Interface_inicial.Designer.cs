﻿namespace APH_e_PV
{
    partial class Interface_inicial
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Interface_inicial));
            this.btnLeisTransformacao = new System.Windows.Forms.Button();
            this.btnCalcVazao = new System.Windows.Forms.Button();
            this.btnSing = new System.Windows.Forms.Button();
            this.btnLinhaPrinc = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.btnSobre = new System.Windows.Forms.Button();
            this.btnAvalia = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnLeisTransformacao
            // 
            this.btnLeisTransformacao.AutoEllipsis = true;
            this.btnLeisTransformacao.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btnLeisTransformacao.BackColor = System.Drawing.Color.Transparent;
            this.btnLeisTransformacao.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnLeisTransformacao.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnLeisTransformacao.FlatAppearance.BorderSize = 0;
            this.btnLeisTransformacao.FlatAppearance.MouseDownBackColor = System.Drawing.SystemColors.Highlight;
            this.btnLeisTransformacao.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnLeisTransformacao.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLeisTransformacao.ForeColor = System.Drawing.Color.Transparent;
            this.btnLeisTransformacao.Image = ((System.Drawing.Image)(resources.GetObject("btnLeisTransformacao.Image")));
            this.btnLeisTransformacao.Location = new System.Drawing.Point(111, 36);
            this.btnLeisTransformacao.Margin = new System.Windows.Forms.Padding(0);
            this.btnLeisTransformacao.Name = "btnLeisTransformacao";
            this.btnLeisTransformacao.Size = new System.Drawing.Size(161, 56);
            this.btnLeisTransformacao.TabIndex = 0;
            this.btnLeisTransformacao.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnLeisTransformacao.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnLeisTransformacao.UseVisualStyleBackColor = false;
            this.btnLeisTransformacao.Click += new System.EventHandler(this.btnLeisTransformacao_Click);
            // 
            // btnCalcVazao
            // 
            this.btnCalcVazao.BackColor = System.Drawing.Color.Transparent;
            this.btnCalcVazao.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnCalcVazao.FlatAppearance.BorderSize = 0;
            this.btnCalcVazao.FlatAppearance.MouseDownBackColor = System.Drawing.SystemColors.Highlight;
            this.btnCalcVazao.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnCalcVazao.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCalcVazao.Image = ((System.Drawing.Image)(resources.GetObject("btnCalcVazao.Image")));
            this.btnCalcVazao.Location = new System.Drawing.Point(111, 94);
            this.btnCalcVazao.Name = "btnCalcVazao";
            this.btnCalcVazao.Size = new System.Drawing.Size(161, 50);
            this.btnCalcVazao.TabIndex = 1;
            this.btnCalcVazao.UseVisualStyleBackColor = false;
            this.btnCalcVazao.Click += new System.EventHandler(this.btnCalcVazao_Click);
            // 
            // btnSing
            // 
            this.btnSing.BackColor = System.Drawing.Color.Transparent;
            this.btnSing.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnSing.FlatAppearance.BorderSize = 0;
            this.btnSing.FlatAppearance.MouseDownBackColor = System.Drawing.SystemColors.Highlight;
            this.btnSing.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnSing.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSing.Image = ((System.Drawing.Image)(resources.GetObject("btnSing.Image")));
            this.btnSing.Location = new System.Drawing.Point(112, 198);
            this.btnSing.Name = "btnSing";
            this.btnSing.Size = new System.Drawing.Size(161, 49);
            this.btnSing.TabIndex = 2;
            this.btnSing.UseVisualStyleBackColor = false;
            this.btnSing.Click += new System.EventHandler(this.btnSing_Click);
            // 
            // btnLinhaPrinc
            // 
            this.btnLinhaPrinc.BackColor = System.Drawing.Color.Transparent;
            this.btnLinhaPrinc.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnLinhaPrinc.FlatAppearance.BorderSize = 0;
            this.btnLinhaPrinc.FlatAppearance.MouseDownBackColor = System.Drawing.SystemColors.Highlight;
            this.btnLinhaPrinc.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnLinhaPrinc.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLinhaPrinc.Image = ((System.Drawing.Image)(resources.GetObject("btnLinhaPrinc.Image")));
            this.btnLinhaPrinc.Location = new System.Drawing.Point(111, 146);
            this.btnLinhaPrinc.Name = "btnLinhaPrinc";
            this.btnLinhaPrinc.Size = new System.Drawing.Size(161, 51);
            this.btnLinhaPrinc.TabIndex = 3;
            this.btnLinhaPrinc.UseVisualStyleBackColor = false;
            this.btnLinhaPrinc.Click += new System.EventHandler(this.btnLinhaPrinc_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Silver;
            this.label1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.MintCream;
            this.label1.Location = new System.Drawing.Point(154, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(74, 25);
            this.label1.TabIndex = 6;
            this.label1.Text = "MENU";
            // 
            // btnSobre
            // 
            this.btnSobre.BackColor = System.Drawing.Color.Transparent;
            this.btnSobre.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnSobre.FlatAppearance.BorderSize = 0;
            this.btnSobre.FlatAppearance.MouseDownBackColor = System.Drawing.SystemColors.Highlight;
            this.btnSobre.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnSobre.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSobre.Image = ((System.Drawing.Image)(resources.GetObject("btnSobre.Image")));
            this.btnSobre.Location = new System.Drawing.Point(111, 250);
            this.btnSobre.Name = "btnSobre";
            this.btnSobre.Size = new System.Drawing.Size(161, 47);
            this.btnSobre.TabIndex = 7;
            this.btnSobre.UseVisualStyleBackColor = false;
            this.btnSobre.Click += new System.EventHandler(this.btnSobre_Click);
            // 
            // btnAvalia
            // 
            this.btnAvalia.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btnAvalia.Location = new System.Drawing.Point(309, 284);
            this.btnAvalia.Name = "btnAvalia";
            this.btnAvalia.Size = new System.Drawing.Size(75, 23);
            this.btnAvalia.TabIndex = 8;
            this.btnAvalia.Text = "Avalie";
            this.btnAvalia.UseVisualStyleBackColor = false;
            this.btnAvalia.Click += new System.EventHandler(this.btnAvalia_Click);
            // 
            // Interface_inicial
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(387, 309);
            this.Controls.Add(this.btnAvalia);
            this.Controls.Add(this.btnSobre);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnLinhaPrinc);
            this.Controls.Add(this.btnSing);
            this.Controls.Add(this.btnCalcVazao);
            this.Controls.Add(this.btnLeisTransformacao);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "Interface_inicial";
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Air Calc";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnLeisTransformacao;
        private System.Windows.Forms.Button btnCalcVazao;
        private System.Windows.Forms.Button btnSing;
        private System.Windows.Forms.Button btnLinhaPrinc;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnSobre;
        private System.Windows.Forms.Button btnAvalia;
    }
}