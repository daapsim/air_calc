﻿namespace APH_e_PV
{
    partial class Dimensionamento_Linha
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Dimensionamento_Linha));
            this.panel1 = new System.Windows.Forms.Panel();
            this.txbPriCompSingu = new System.Windows.Forms.TextBox();
            this.txbAuCap = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.lblPriCompSing = new System.Windows.Forms.Label();
            this.txbPress = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txbPerda = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txbComp = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txbVaz = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btnCalc1 = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.lblPriRes = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.lblSecDiaResp5 = new System.Windows.Forms.Label();
            this.lblSecDia5 = new System.Windows.Forms.Label();
            this.txbSecSing5 = new System.Windows.Forms.TextBox();
            this.lblSecSing5 = new System.Windows.Forms.Label();
            this.txbSecQtd5 = new System.Windows.Forms.TextBox();
            this.lblSecQtd5 = new System.Windows.Forms.Label();
            this.txbSecComp5 = new System.Windows.Forms.TextBox();
            this.lblSecComp5 = new System.Windows.Forms.Label();
            this.lblSecDiaResp4 = new System.Windows.Forms.Label();
            this.lblSecDia4 = new System.Windows.Forms.Label();
            this.txbSecSing4 = new System.Windows.Forms.TextBox();
            this.lblSecSing4 = new System.Windows.Forms.Label();
            this.txbSecQtd4 = new System.Windows.Forms.TextBox();
            this.lblSecQtd4 = new System.Windows.Forms.Label();
            this.txbSecComp4 = new System.Windows.Forms.TextBox();
            this.lblSecComp4 = new System.Windows.Forms.Label();
            this.lblSecDiaResp3 = new System.Windows.Forms.Label();
            this.lblSecDiaResp2 = new System.Windows.Forms.Label();
            this.lblSecDiaResp1 = new System.Windows.Forms.Label();
            this.lblSecDia3 = new System.Windows.Forms.Label();
            this.txbSecSing3 = new System.Windows.Forms.TextBox();
            this.lblSecSing3 = new System.Windows.Forms.Label();
            this.txbSecQtd3 = new System.Windows.Forms.TextBox();
            this.lblSecQtd3 = new System.Windows.Forms.Label();
            this.lblSecDia2 = new System.Windows.Forms.Label();
            this.txbSecSing2 = new System.Windows.Forms.TextBox();
            this.lblSecSing2 = new System.Windows.Forms.Label();
            this.txbSecQtd2 = new System.Windows.Forms.TextBox();
            this.lblSecQtd2 = new System.Windows.Forms.Label();
            this.lblSecDia1 = new System.Windows.Forms.Label();
            this.txbSecSing1 = new System.Windows.Forms.TextBox();
            this.lblSecSing1 = new System.Windows.Forms.Label();
            this.lblSecComp2 = new System.Windows.Forms.Label();
            this.txbSecComp3 = new System.Windows.Forms.TextBox();
            this.txbSecComp2 = new System.Windows.Forms.TextBox();
            this.lblSecComp3 = new System.Windows.Forms.Label();
            this.txbSecComp1 = new System.Windows.Forms.TextBox();
            this.lblSecQtd1 = new System.Windows.Forms.Label();
            this.txbSecQtd1 = new System.Windows.Forms.TextBox();
            this.lblSecComp1 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.btnLinhaSecAdd = new System.Windows.Forms.Button();
            this.btnLinhaSecDel = new System.Windows.Forms.Button();
            this.btnCalcSec = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.lblAlimDiaResp5 = new System.Windows.Forms.Label();
            this.lblAlimDia5 = new System.Windows.Forms.Label();
            this.txbAlimSing5 = new System.Windows.Forms.TextBox();
            this.lblAlimSing5 = new System.Windows.Forms.Label();
            this.txbAlimQtd5 = new System.Windows.Forms.TextBox();
            this.lblAlimQtd5 = new System.Windows.Forms.Label();
            this.lblAlimDiaResp4 = new System.Windows.Forms.Label();
            this.lblAlimDia4 = new System.Windows.Forms.Label();
            this.txbAlimSing4 = new System.Windows.Forms.TextBox();
            this.lblAlimSing4 = new System.Windows.Forms.Label();
            this.txbAlimQtd4 = new System.Windows.Forms.TextBox();
            this.lblAlimQtd4 = new System.Windows.Forms.Label();
            this.lblAlimDiaResp3 = new System.Windows.Forms.Label();
            this.lblAlimDiaResp2 = new System.Windows.Forms.Label();
            this.lblAlimDiaResp1 = new System.Windows.Forms.Label();
            this.lblAlimDia3 = new System.Windows.Forms.Label();
            this.txbAlimSing3 = new System.Windows.Forms.TextBox();
            this.lblAlimSing3 = new System.Windows.Forms.Label();
            this.txbAlimQtd3 = new System.Windows.Forms.TextBox();
            this.lblAlimQtd3 = new System.Windows.Forms.Label();
            this.lblAlimDia2 = new System.Windows.Forms.Label();
            this.txbAlimSing2 = new System.Windows.Forms.TextBox();
            this.lblAlimSing2 = new System.Windows.Forms.Label();
            this.txbAlimQtd2 = new System.Windows.Forms.TextBox();
            this.lblAlimQtd2 = new System.Windows.Forms.Label();
            this.lblAlimDia1 = new System.Windows.Forms.Label();
            this.txbAlimSing1 = new System.Windows.Forms.TextBox();
            this.lblAlimSing1 = new System.Windows.Forms.Label();
            this.lblAlimQtd1 = new System.Windows.Forms.Label();
            this.txbAlimQtd1 = new System.Windows.Forms.TextBox();
            this.btnCalcAlim = new System.Windows.Forms.Button();
            this.btnTabela2 = new System.Windows.Forms.Button();
            this.lblInfo = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.AutoScroll = true;
            this.panel1.BackColor = System.Drawing.Color.Transparent;
            this.panel1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel1.BackgroundImage")));
            this.panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel1.Controls.Add(this.txbPriCompSingu);
            this.panel1.Controls.Add(this.txbAuCap);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.lblPriCompSing);
            this.panel1.Controls.Add(this.txbPress);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.txbPerda);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.txbComp);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.txbVaz);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Location = new System.Drawing.Point(3, 30);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(208, 319);
            this.panel1.TabIndex = 0;
            // 
            // txbPriCompSingu
            // 
            this.txbPriCompSingu.Location = new System.Drawing.Point(12, 90);
            this.txbPriCompSingu.Name = "txbPriCompSingu";
            this.txbPriCompSingu.Size = new System.Drawing.Size(141, 20);
            this.txbPriCompSingu.TabIndex = 11;
            this.txbPriCompSingu.Click += new System.EventHandler(this.txbPriCompSingu_Click);
            // 
            // txbAuCap
            // 
            this.txbAuCap.Location = new System.Drawing.Point(12, 286);
            this.txbAuCap.Name = "txbAuCap";
            this.txbAuCap.Size = new System.Drawing.Size(160, 20);
            this.txbAuCap.TabIndex = 9;
            this.txbAuCap.Click += new System.EventHandler(this.txbAuCap_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(9, 265);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(192, 13);
            this.label6.TabIndex = 8;
            this.label6.Text = "Aumento capacidade prevista(%)";
            // 
            // lblPriCompSing
            // 
            this.lblPriCompSing.AutoSize = true;
            this.lblPriCompSing.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPriCompSing.Location = new System.Drawing.Point(9, 69);
            this.lblPriCompSing.Name = "lblPriCompSing";
            this.lblPriCompSing.Size = new System.Drawing.Size(171, 13);
            this.lblPriCompSing.TabIndex = 10;
            this.lblPriCompSing.Text = "Comprimento da Sigularidade";
            // 
            // txbPress
            // 
            this.txbPress.Location = new System.Drawing.Point(12, 237);
            this.txbPress.Name = "txbPress";
            this.txbPress.Size = new System.Drawing.Size(134, 20);
            this.txbPress.TabIndex = 7;
            this.txbPress.Click += new System.EventHandler(this.txbPress_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(9, 216);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(124, 13);
            this.label5.TabIndex = 6;
            this.label5.Text = "Pressão de Trabalho";
            // 
            // txbPerda
            // 
            this.txbPerda.Location = new System.Drawing.Point(12, 188);
            this.txbPerda.Name = "txbPerda";
            this.txbPerda.Size = new System.Drawing.Size(134, 20);
            this.txbPerda.TabIndex = 5;
            this.txbPerda.Click += new System.EventHandler(this.txbPerda_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(9, 167);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(95, 13);
            this.label4.TabIndex = 4;
            this.label4.Text = "Perda de Carga";
            // 
            // txbComp
            // 
            this.txbComp.Location = new System.Drawing.Point(12, 41);
            this.txbComp.Name = "txbComp";
            this.txbComp.Size = new System.Drawing.Size(134, 20);
            this.txbComp.TabIndex = 2;
            this.txbComp.Click += new System.EventHandler(this.txbComp_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(9, 118);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(63, 13);
            this.label3.TabIndex = 1;
            this.label3.Text = "Vazão (Q)";
            // 
            // txbVaz
            // 
            this.txbVaz.Location = new System.Drawing.Point(12, 139);
            this.txbVaz.Name = "txbVaz";
            this.txbVaz.Size = new System.Drawing.Size(134, 20);
            this.txbVaz.TabIndex = 3;
            this.txbVaz.Click += new System.EventHandler(this.txbVaz_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(9, 20);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(161, 13);
            this.label2.TabIndex = 0;
            this.label2.Text = "Comprimento da Tubulação";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 11);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(104, 15);
            this.label1.TabIndex = 1;
            this.label1.Text = "Linha Principal";
            // 
            // btnCalc1
            // 
            this.btnCalc1.BackColor = System.Drawing.Color.Transparent;
            this.btnCalc1.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnCalc1.FlatAppearance.BorderSize = 0;
            this.btnCalc1.FlatAppearance.MouseDownBackColor = System.Drawing.SystemColors.Highlight;
            this.btnCalc1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnCalc1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCalc1.Image = ((System.Drawing.Image)(resources.GetObject("btnCalc1.Image")));
            this.btnCalc1.Location = new System.Drawing.Point(12, 349);
            this.btnCalc1.Name = "btnCalc1";
            this.btnCalc1.Size = new System.Drawing.Size(185, 35);
            this.btnCalc1.TabIndex = 10;
            this.btnCalc1.UseVisualStyleBackColor = false;
            this.btnCalc1.Click += new System.EventHandler(this.btnCalc1_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(12, 390);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(80, 15);
            this.label7.TabIndex = 10;
            this.label7.Text = "Resultado: ";
            // 
            // lblPriRes
            // 
            this.lblPriRes.AutoSize = true;
            this.lblPriRes.Location = new System.Drawing.Point(127, 390);
            this.lblPriRes.Name = "lblPriRes";
            this.lblPriRes.Size = new System.Drawing.Size(22, 13);
            this.lblPriRes.TabIndex = 11;
            this.lblPriRes.Text = "-----";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(233, 223);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(146, 15);
            this.label9.TabIndex = 13;
            this.label9.Text = "Linha de Alimentação";
            // 
            // panel3
            // 
            this.panel3.AutoScroll = true;
            this.panel3.BackColor = System.Drawing.Color.Transparent;
            this.panel3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel3.BackgroundImage")));
            this.panel3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel3.Controls.Add(this.lblSecDiaResp5);
            this.panel3.Controls.Add(this.lblSecDia5);
            this.panel3.Controls.Add(this.txbSecSing5);
            this.panel3.Controls.Add(this.lblSecSing5);
            this.panel3.Controls.Add(this.txbSecQtd5);
            this.panel3.Controls.Add(this.lblSecQtd5);
            this.panel3.Controls.Add(this.txbSecComp5);
            this.panel3.Controls.Add(this.lblSecComp5);
            this.panel3.Controls.Add(this.lblSecDiaResp4);
            this.panel3.Controls.Add(this.lblSecDia4);
            this.panel3.Controls.Add(this.txbSecSing4);
            this.panel3.Controls.Add(this.lblSecSing4);
            this.panel3.Controls.Add(this.txbSecQtd4);
            this.panel3.Controls.Add(this.lblSecQtd4);
            this.panel3.Controls.Add(this.txbSecComp4);
            this.panel3.Controls.Add(this.lblSecComp4);
            this.panel3.Controls.Add(this.lblSecDiaResp3);
            this.panel3.Controls.Add(this.lblSecDiaResp2);
            this.panel3.Controls.Add(this.lblSecDiaResp1);
            this.panel3.Controls.Add(this.lblSecDia3);
            this.panel3.Controls.Add(this.txbSecSing3);
            this.panel3.Controls.Add(this.lblSecSing3);
            this.panel3.Controls.Add(this.txbSecQtd3);
            this.panel3.Controls.Add(this.lblSecQtd3);
            this.panel3.Controls.Add(this.lblSecDia2);
            this.panel3.Controls.Add(this.txbSecSing2);
            this.panel3.Controls.Add(this.lblSecSing2);
            this.panel3.Controls.Add(this.txbSecQtd2);
            this.panel3.Controls.Add(this.lblSecQtd2);
            this.panel3.Controls.Add(this.lblSecDia1);
            this.panel3.Controls.Add(this.txbSecSing1);
            this.panel3.Controls.Add(this.lblSecSing1);
            this.panel3.Controls.Add(this.lblSecComp2);
            this.panel3.Controls.Add(this.txbSecComp3);
            this.panel3.Controls.Add(this.txbSecComp2);
            this.panel3.Controls.Add(this.lblSecComp3);
            this.panel3.Controls.Add(this.txbSecComp1);
            this.panel3.Controls.Add(this.lblSecQtd1);
            this.panel3.Controls.Add(this.txbSecQtd1);
            this.panel3.Controls.Add(this.lblSecComp1);
            this.panel3.Location = new System.Drawing.Point(217, 30);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(411, 107);
            this.panel3.TabIndex = 10;
            // 
            // lblSecDiaResp5
            // 
            this.lblSecDiaResp5.AutoSize = true;
            this.lblSecDiaResp5.Location = new System.Drawing.Point(329, 251);
            this.lblSecDiaResp5.Name = "lblSecDiaResp5";
            this.lblSecDiaResp5.Size = new System.Drawing.Size(22, 13);
            this.lblSecDiaResp5.TabIndex = 44;
            this.lblSecDiaResp5.Text = "-----";
            this.lblSecDiaResp5.Visible = false;
            // 
            // lblSecDia5
            // 
            this.lblSecDia5.AutoSize = true;
            this.lblSecDia5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSecDia5.Location = new System.Drawing.Point(322, 224);
            this.lblSecDia5.Name = "lblSecDia5";
            this.lblSecDia5.Size = new System.Drawing.Size(57, 13);
            this.lblSecDia5.TabIndex = 43;
            this.lblSecDia5.Text = "Diâmetro";
            this.lblSecDia5.Visible = false;
            // 
            // txbSecSing5
            // 
            this.txbSecSing5.Location = new System.Drawing.Point(232, 248);
            this.txbSecSing5.Name = "txbSecSing5";
            this.txbSecSing5.Size = new System.Drawing.Size(70, 20);
            this.txbSecSing5.TabIndex = 42;
            this.txbSecSing5.Visible = false;
            this.txbSecSing5.Click += new System.EventHandler(this.txbSecSing5_Click);
            // 
            // lblSecSing5
            // 
            this.lblSecSing5.AutoSize = true;
            this.lblSecSing5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSecSing5.Location = new System.Drawing.Point(229, 224);
            this.lblSecSing5.Name = "lblSecSing5";
            this.lblSecSing5.Size = new System.Drawing.Size(87, 13);
            this.lblSecSing5.TabIndex = 41;
            this.lblSecSing5.Text = "Singularides 5";
            this.lblSecSing5.Visible = false;
            // 
            // txbSecQtd5
            // 
            this.txbSecQtd5.Location = new System.Drawing.Point(160, 248);
            this.txbSecQtd5.Name = "txbSecQtd5";
            this.txbSecQtd5.Size = new System.Drawing.Size(51, 20);
            this.txbSecQtd5.TabIndex = 40;
            this.txbSecQtd5.Visible = false;
            this.txbSecQtd5.Click += new System.EventHandler(this.txbSecQtd5_Click);
            // 
            // lblSecQtd5
            // 
            this.lblSecQtd5.AutoSize = true;
            this.lblSecQtd5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSecQtd5.Location = new System.Drawing.Point(157, 224);
            this.lblSecQtd5.Name = "lblSecQtd5";
            this.lblSecQtd5.Size = new System.Drawing.Size(31, 13);
            this.lblSecQtd5.TabIndex = 39;
            this.lblSecQtd5.Text = "Qtd.";
            this.lblSecQtd5.Visible = false;
            // 
            // txbSecComp5
            // 
            this.txbSecComp5.Location = new System.Drawing.Point(7, 248);
            this.txbSecComp5.Name = "txbSecComp5";
            this.txbSecComp5.Size = new System.Drawing.Size(134, 20);
            this.txbSecComp5.TabIndex = 38;
            this.txbSecComp5.Visible = false;
            this.txbSecComp5.Click += new System.EventHandler(this.txbSecComp5_Click);
            // 
            // lblSecComp5
            // 
            this.lblSecComp5.AutoSize = true;
            this.lblSecComp5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSecComp5.Location = new System.Drawing.Point(4, 224);
            this.lblSecComp5.Name = "lblSecComp5";
            this.lblSecComp5.Size = new System.Drawing.Size(90, 13);
            this.lblSecComp5.TabIndex = 37;
            this.lblSecComp5.Text = "Comprimento 5";
            this.lblSecComp5.Visible = false;
            // 
            // lblSecDiaResp4
            // 
            this.lblSecDiaResp4.AutoSize = true;
            this.lblSecDiaResp4.Location = new System.Drawing.Point(329, 196);
            this.lblSecDiaResp4.Name = "lblSecDiaResp4";
            this.lblSecDiaResp4.Size = new System.Drawing.Size(22, 13);
            this.lblSecDiaResp4.TabIndex = 36;
            this.lblSecDiaResp4.Text = "-----";
            this.lblSecDiaResp4.Visible = false;
            // 
            // lblSecDia4
            // 
            this.lblSecDia4.AutoSize = true;
            this.lblSecDia4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSecDia4.Location = new System.Drawing.Point(322, 169);
            this.lblSecDia4.Name = "lblSecDia4";
            this.lblSecDia4.Size = new System.Drawing.Size(57, 13);
            this.lblSecDia4.TabIndex = 35;
            this.lblSecDia4.Text = "Diâmetro";
            this.lblSecDia4.Visible = false;
            // 
            // txbSecSing4
            // 
            this.txbSecSing4.Location = new System.Drawing.Point(232, 193);
            this.txbSecSing4.Name = "txbSecSing4";
            this.txbSecSing4.Size = new System.Drawing.Size(70, 20);
            this.txbSecSing4.TabIndex = 34;
            this.txbSecSing4.Visible = false;
            this.txbSecSing4.Click += new System.EventHandler(this.txbSecSing4_Click);
            // 
            // lblSecSing4
            // 
            this.lblSecSing4.AutoSize = true;
            this.lblSecSing4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSecSing4.Location = new System.Drawing.Point(229, 169);
            this.lblSecSing4.Name = "lblSecSing4";
            this.lblSecSing4.Size = new System.Drawing.Size(87, 13);
            this.lblSecSing4.TabIndex = 33;
            this.lblSecSing4.Text = "Singularides 4";
            this.lblSecSing4.Visible = false;
            // 
            // txbSecQtd4
            // 
            this.txbSecQtd4.Location = new System.Drawing.Point(160, 193);
            this.txbSecQtd4.Name = "txbSecQtd4";
            this.txbSecQtd4.Size = new System.Drawing.Size(51, 20);
            this.txbSecQtd4.TabIndex = 32;
            this.txbSecQtd4.Visible = false;
            this.txbSecQtd4.Click += new System.EventHandler(this.txbSecQtd4_Click);
            // 
            // lblSecQtd4
            // 
            this.lblSecQtd4.AutoSize = true;
            this.lblSecQtd4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSecQtd4.Location = new System.Drawing.Point(157, 169);
            this.lblSecQtd4.Name = "lblSecQtd4";
            this.lblSecQtd4.Size = new System.Drawing.Size(31, 13);
            this.lblSecQtd4.TabIndex = 31;
            this.lblSecQtd4.Text = "Qtd.";
            this.lblSecQtd4.Visible = false;
            // 
            // txbSecComp4
            // 
            this.txbSecComp4.Location = new System.Drawing.Point(7, 193);
            this.txbSecComp4.Name = "txbSecComp4";
            this.txbSecComp4.Size = new System.Drawing.Size(134, 20);
            this.txbSecComp4.TabIndex = 30;
            this.txbSecComp4.Visible = false;
            this.txbSecComp4.Click += new System.EventHandler(this.txbSecComp4_Click);
            // 
            // lblSecComp4
            // 
            this.lblSecComp4.AutoSize = true;
            this.lblSecComp4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSecComp4.Location = new System.Drawing.Point(4, 169);
            this.lblSecComp4.Name = "lblSecComp4";
            this.lblSecComp4.Size = new System.Drawing.Size(90, 13);
            this.lblSecComp4.TabIndex = 29;
            this.lblSecComp4.Text = "Comprimento 4";
            this.lblSecComp4.Visible = false;
            // 
            // lblSecDiaResp3
            // 
            this.lblSecDiaResp3.AutoSize = true;
            this.lblSecDiaResp3.Location = new System.Drawing.Point(329, 141);
            this.lblSecDiaResp3.Name = "lblSecDiaResp3";
            this.lblSecDiaResp3.Size = new System.Drawing.Size(22, 13);
            this.lblSecDiaResp3.TabIndex = 28;
            this.lblSecDiaResp3.Text = "-----";
            this.lblSecDiaResp3.Visible = false;
            // 
            // lblSecDiaResp2
            // 
            this.lblSecDiaResp2.AutoSize = true;
            this.lblSecDiaResp2.Location = new System.Drawing.Point(329, 88);
            this.lblSecDiaResp2.Name = "lblSecDiaResp2";
            this.lblSecDiaResp2.Size = new System.Drawing.Size(22, 13);
            this.lblSecDiaResp2.TabIndex = 27;
            this.lblSecDiaResp2.Text = "-----";
            this.lblSecDiaResp2.Visible = false;
            // 
            // lblSecDiaResp1
            // 
            this.lblSecDiaResp1.AutoSize = true;
            this.lblSecDiaResp1.Location = new System.Drawing.Point(329, 32);
            this.lblSecDiaResp1.Name = "lblSecDiaResp1";
            this.lblSecDiaResp1.Size = new System.Drawing.Size(22, 13);
            this.lblSecDiaResp1.TabIndex = 26;
            this.lblSecDiaResp1.Text = "-----";
            // 
            // lblSecDia3
            // 
            this.lblSecDia3.AutoSize = true;
            this.lblSecDia3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSecDia3.Location = new System.Drawing.Point(322, 114);
            this.lblSecDia3.Name = "lblSecDia3";
            this.lblSecDia3.Size = new System.Drawing.Size(57, 13);
            this.lblSecDia3.TabIndex = 25;
            this.lblSecDia3.Text = "Diâmetro";
            this.lblSecDia3.Visible = false;
            // 
            // txbSecSing3
            // 
            this.txbSecSing3.Location = new System.Drawing.Point(232, 138);
            this.txbSecSing3.Name = "txbSecSing3";
            this.txbSecSing3.Size = new System.Drawing.Size(70, 20);
            this.txbSecSing3.TabIndex = 24;
            this.txbSecSing3.Visible = false;
            this.txbSecSing3.Click += new System.EventHandler(this.txbSecSing3_Click);
            // 
            // lblSecSing3
            // 
            this.lblSecSing3.AutoSize = true;
            this.lblSecSing3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSecSing3.Location = new System.Drawing.Point(229, 114);
            this.lblSecSing3.Name = "lblSecSing3";
            this.lblSecSing3.Size = new System.Drawing.Size(87, 13);
            this.lblSecSing3.TabIndex = 23;
            this.lblSecSing3.Text = "Singularides 3";
            this.lblSecSing3.Visible = false;
            // 
            // txbSecQtd3
            // 
            this.txbSecQtd3.Location = new System.Drawing.Point(160, 138);
            this.txbSecQtd3.Name = "txbSecQtd3";
            this.txbSecQtd3.Size = new System.Drawing.Size(51, 20);
            this.txbSecQtd3.TabIndex = 22;
            this.txbSecQtd3.Visible = false;
            this.txbSecQtd3.Click += new System.EventHandler(this.txbSecQtd3_Click);
            // 
            // lblSecQtd3
            // 
            this.lblSecQtd3.AutoSize = true;
            this.lblSecQtd3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSecQtd3.Location = new System.Drawing.Point(157, 114);
            this.lblSecQtd3.Name = "lblSecQtd3";
            this.lblSecQtd3.Size = new System.Drawing.Size(31, 13);
            this.lblSecQtd3.TabIndex = 21;
            this.lblSecQtd3.Text = "Qtd.";
            this.lblSecQtd3.Visible = false;
            // 
            // lblSecDia2
            // 
            this.lblSecDia2.AutoSize = true;
            this.lblSecDia2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSecDia2.Location = new System.Drawing.Point(317, 60);
            this.lblSecDia2.Name = "lblSecDia2";
            this.lblSecDia2.Size = new System.Drawing.Size(57, 13);
            this.lblSecDia2.TabIndex = 19;
            this.lblSecDia2.Text = "Diâmetro";
            this.lblSecDia2.Visible = false;
            // 
            // txbSecSing2
            // 
            this.txbSecSing2.Location = new System.Drawing.Point(232, 83);
            this.txbSecSing2.Name = "txbSecSing2";
            this.txbSecSing2.Size = new System.Drawing.Size(70, 20);
            this.txbSecSing2.TabIndex = 18;
            this.txbSecSing2.Visible = false;
            this.txbSecSing2.Click += new System.EventHandler(this.txbSecSing2_Click);
            // 
            // lblSecSing2
            // 
            this.lblSecSing2.AutoSize = true;
            this.lblSecSing2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSecSing2.Location = new System.Drawing.Point(229, 59);
            this.lblSecSing2.Name = "lblSecSing2";
            this.lblSecSing2.Size = new System.Drawing.Size(87, 13);
            this.lblSecSing2.TabIndex = 17;
            this.lblSecSing2.Text = "Singularides 2";
            this.lblSecSing2.Visible = false;
            // 
            // txbSecQtd2
            // 
            this.txbSecQtd2.Location = new System.Drawing.Point(160, 83);
            this.txbSecQtd2.Name = "txbSecQtd2";
            this.txbSecQtd2.Size = new System.Drawing.Size(51, 20);
            this.txbSecQtd2.TabIndex = 16;
            this.txbSecQtd2.Visible = false;
            this.txbSecQtd2.Click += new System.EventHandler(this.txbSecQtd2_Click);
            // 
            // lblSecQtd2
            // 
            this.lblSecQtd2.AutoSize = true;
            this.lblSecQtd2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSecQtd2.Location = new System.Drawing.Point(157, 59);
            this.lblSecQtd2.Name = "lblSecQtd2";
            this.lblSecQtd2.Size = new System.Drawing.Size(31, 13);
            this.lblSecQtd2.TabIndex = 15;
            this.lblSecQtd2.Text = "Qtd.";
            this.lblSecQtd2.Visible = false;
            // 
            // lblSecDia1
            // 
            this.lblSecDia1.AutoSize = true;
            this.lblSecDia1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSecDia1.Location = new System.Drawing.Point(317, 4);
            this.lblSecDia1.Name = "lblSecDia1";
            this.lblSecDia1.Size = new System.Drawing.Size(57, 13);
            this.lblSecDia1.TabIndex = 13;
            this.lblSecDia1.Text = "Diâmetro";
            // 
            // txbSecSing1
            // 
            this.txbSecSing1.Location = new System.Drawing.Point(232, 28);
            this.txbSecSing1.Name = "txbSecSing1";
            this.txbSecSing1.Size = new System.Drawing.Size(70, 20);
            this.txbSecSing1.TabIndex = 12;
            this.txbSecSing1.Click += new System.EventHandler(this.txbSecSing1_Click);
            // 
            // lblSecSing1
            // 
            this.lblSecSing1.AutoSize = true;
            this.lblSecSing1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSecSing1.Location = new System.Drawing.Point(229, 4);
            this.lblSecSing1.Name = "lblSecSing1";
            this.lblSecSing1.Size = new System.Drawing.Size(87, 13);
            this.lblSecSing1.TabIndex = 11;
            this.lblSecSing1.Text = "Singularides 1";
            // 
            // lblSecComp2
            // 
            this.lblSecComp2.AutoSize = true;
            this.lblSecComp2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSecComp2.Location = new System.Drawing.Point(4, 59);
            this.lblSecComp2.Name = "lblSecComp2";
            this.lblSecComp2.Size = new System.Drawing.Size(90, 13);
            this.lblSecComp2.TabIndex = 10;
            this.lblSecComp2.Text = "Comprimento 2";
            this.lblSecComp2.Visible = false;
            // 
            // txbSecComp3
            // 
            this.txbSecComp3.Location = new System.Drawing.Point(7, 138);
            this.txbSecComp3.Name = "txbSecComp3";
            this.txbSecComp3.Size = new System.Drawing.Size(134, 20);
            this.txbSecComp3.TabIndex = 7;
            this.txbSecComp3.Visible = false;
            this.txbSecComp3.Click += new System.EventHandler(this.txbSecComp3_Click);
            // 
            // txbSecComp2
            // 
            this.txbSecComp2.Location = new System.Drawing.Point(7, 83);
            this.txbSecComp2.Name = "txbSecComp2";
            this.txbSecComp2.Size = new System.Drawing.Size(134, 20);
            this.txbSecComp2.TabIndex = 5;
            this.txbSecComp2.Visible = false;
            this.txbSecComp2.Click += new System.EventHandler(this.txbSecComp2_Click);
            // 
            // lblSecComp3
            // 
            this.lblSecComp3.AutoSize = true;
            this.lblSecComp3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSecComp3.Location = new System.Drawing.Point(4, 114);
            this.lblSecComp3.Name = "lblSecComp3";
            this.lblSecComp3.Size = new System.Drawing.Size(90, 13);
            this.lblSecComp3.TabIndex = 4;
            this.lblSecComp3.Text = "Comprimento 3";
            this.lblSecComp3.Visible = false;
            // 
            // txbSecComp1
            // 
            this.txbSecComp1.Location = new System.Drawing.Point(7, 28);
            this.txbSecComp1.Name = "txbSecComp1";
            this.txbSecComp1.Size = new System.Drawing.Size(134, 20);
            this.txbSecComp1.TabIndex = 2;
            this.txbSecComp1.Click += new System.EventHandler(this.txbSecComp1_Click);
            // 
            // lblSecQtd1
            // 
            this.lblSecQtd1.AutoSize = true;
            this.lblSecQtd1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSecQtd1.Location = new System.Drawing.Point(157, 4);
            this.lblSecQtd1.Name = "lblSecQtd1";
            this.lblSecQtd1.Size = new System.Drawing.Size(31, 13);
            this.lblSecQtd1.TabIndex = 1;
            this.lblSecQtd1.Text = "Qtd.";
            // 
            // txbSecQtd1
            // 
            this.txbSecQtd1.Location = new System.Drawing.Point(160, 28);
            this.txbSecQtd1.Name = "txbSecQtd1";
            this.txbSecQtd1.Size = new System.Drawing.Size(51, 20);
            this.txbSecQtd1.TabIndex = 3;
            this.txbSecQtd1.Click += new System.EventHandler(this.txbSecQtd1_Click);
            // 
            // lblSecComp1
            // 
            this.lblSecComp1.AutoSize = true;
            this.lblSecComp1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSecComp1.Location = new System.Drawing.Point(4, 4);
            this.lblSecComp1.Name = "lblSecComp1";
            this.lblSecComp1.Size = new System.Drawing.Size(90, 13);
            this.lblSecComp1.TabIndex = 0;
            this.lblSecComp1.Text = "Comprimento 1";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(233, 11);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(120, 15);
            this.label17.TabIndex = 14;
            this.label17.Text = "Linha Secundária";
            // 
            // btnLinhaSecAdd
            // 
            this.btnLinhaSecAdd.BackColor = System.Drawing.Color.Transparent;
            this.btnLinhaSecAdd.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnLinhaSecAdd.FlatAppearance.BorderSize = 0;
            this.btnLinhaSecAdd.FlatAppearance.MouseDownBackColor = System.Drawing.SystemColors.Highlight;
            this.btnLinhaSecAdd.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnLinhaSecAdd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLinhaSecAdd.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.btnLinhaSecAdd.Image = ((System.Drawing.Image)(resources.GetObject("btnLinhaSecAdd.Image")));
            this.btnLinhaSecAdd.Location = new System.Drawing.Point(217, 141);
            this.btnLinhaSecAdd.Name = "btnLinhaSecAdd";
            this.btnLinhaSecAdd.Size = new System.Drawing.Size(190, 34);
            this.btnLinhaSecAdd.TabIndex = 15;
            this.btnLinhaSecAdd.UseVisualStyleBackColor = false;
            this.btnLinhaSecAdd.Click += new System.EventHandler(this.btnLinhaSecAdd_Click);
            // 
            // btnLinhaSecDel
            // 
            this.btnLinhaSecDel.BackColor = System.Drawing.Color.Transparent;
            this.btnLinhaSecDel.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnLinhaSecDel.FlatAppearance.BorderSize = 0;
            this.btnLinhaSecDel.FlatAppearance.MouseDownBackColor = System.Drawing.SystemColors.Highlight;
            this.btnLinhaSecDel.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnLinhaSecDel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLinhaSecDel.Image = ((System.Drawing.Image)(resources.GetObject("btnLinhaSecDel.Image")));
            this.btnLinhaSecDel.Location = new System.Drawing.Point(444, 143);
            this.btnLinhaSecDel.Name = "btnLinhaSecDel";
            this.btnLinhaSecDel.Size = new System.Drawing.Size(184, 31);
            this.btnLinhaSecDel.TabIndex = 16;
            this.btnLinhaSecDel.UseVisualStyleBackColor = false;
            this.btnLinhaSecDel.Click += new System.EventHandler(this.btnLinhaSecDel_Click);
            // 
            // btnCalcSec
            // 
            this.btnCalcSec.BackColor = System.Drawing.Color.Transparent;
            this.btnCalcSec.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnCalcSec.FlatAppearance.BorderSize = 0;
            this.btnCalcSec.FlatAppearance.MouseDownBackColor = System.Drawing.SystemColors.Highlight;
            this.btnCalcSec.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnCalcSec.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCalcSec.Image = ((System.Drawing.Image)(resources.GetObject("btnCalcSec.Image")));
            this.btnCalcSec.Location = new System.Drawing.Point(217, 177);
            this.btnCalcSec.Name = "btnCalcSec";
            this.btnCalcSec.Size = new System.Drawing.Size(190, 35);
            this.btnCalcSec.TabIndex = 17;
            this.btnCalcSec.UseVisualStyleBackColor = false;
            this.btnCalcSec.Click += new System.EventHandler(this.btnCalcSec_Click);
            // 
            // panel2
            // 
            this.panel2.AutoScroll = true;
            this.panel2.BackColor = System.Drawing.Color.Transparent;
            this.panel2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel2.BackgroundImage")));
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel2.Controls.Add(this.lblAlimDiaResp5);
            this.panel2.Controls.Add(this.lblAlimDia5);
            this.panel2.Controls.Add(this.txbAlimSing5);
            this.panel2.Controls.Add(this.lblAlimSing5);
            this.panel2.Controls.Add(this.txbAlimQtd5);
            this.panel2.Controls.Add(this.lblAlimQtd5);
            this.panel2.Controls.Add(this.lblAlimDiaResp4);
            this.panel2.Controls.Add(this.lblAlimDia4);
            this.panel2.Controls.Add(this.txbAlimSing4);
            this.panel2.Controls.Add(this.lblAlimSing4);
            this.panel2.Controls.Add(this.txbAlimQtd4);
            this.panel2.Controls.Add(this.lblAlimQtd4);
            this.panel2.Controls.Add(this.lblAlimDiaResp3);
            this.panel2.Controls.Add(this.lblAlimDiaResp2);
            this.panel2.Controls.Add(this.lblAlimDiaResp1);
            this.panel2.Controls.Add(this.lblAlimDia3);
            this.panel2.Controls.Add(this.txbAlimSing3);
            this.panel2.Controls.Add(this.lblAlimSing3);
            this.panel2.Controls.Add(this.txbAlimQtd3);
            this.panel2.Controls.Add(this.lblAlimQtd3);
            this.panel2.Controls.Add(this.lblAlimDia2);
            this.panel2.Controls.Add(this.txbAlimSing2);
            this.panel2.Controls.Add(this.lblAlimSing2);
            this.panel2.Controls.Add(this.txbAlimQtd2);
            this.panel2.Controls.Add(this.lblAlimQtd2);
            this.panel2.Controls.Add(this.lblAlimDia1);
            this.panel2.Controls.Add(this.txbAlimSing1);
            this.panel2.Controls.Add(this.lblAlimSing1);
            this.panel2.Controls.Add(this.lblAlimQtd1);
            this.panel2.Controls.Add(this.txbAlimQtd1);
            this.panel2.Location = new System.Drawing.Point(217, 241);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(419, 187);
            this.panel2.TabIndex = 45;
            // 
            // lblAlimDiaResp5
            // 
            this.lblAlimDiaResp5.AutoSize = true;
            this.lblAlimDiaResp5.BackColor = System.Drawing.Color.Transparent;
            this.lblAlimDiaResp5.Location = new System.Drawing.Point(344, 244);
            this.lblAlimDiaResp5.Name = "lblAlimDiaResp5";
            this.lblAlimDiaResp5.Size = new System.Drawing.Size(22, 13);
            this.lblAlimDiaResp5.TabIndex = 44;
            this.lblAlimDiaResp5.Text = "-----";
            this.lblAlimDiaResp5.Visible = false;
            // 
            // lblAlimDia5
            // 
            this.lblAlimDia5.AutoSize = true;
            this.lblAlimDia5.BackColor = System.Drawing.Color.Transparent;
            this.lblAlimDia5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAlimDia5.Location = new System.Drawing.Point(327, 219);
            this.lblAlimDia5.Name = "lblAlimDia5";
            this.lblAlimDia5.Size = new System.Drawing.Size(57, 13);
            this.lblAlimDia5.TabIndex = 43;
            this.lblAlimDia5.Text = "Diâmetro";
            this.lblAlimDia5.Visible = false;
            // 
            // txbAlimSing5
            // 
            this.txbAlimSing5.Location = new System.Drawing.Point(219, 241);
            this.txbAlimSing5.Name = "txbAlimSing5";
            this.txbAlimSing5.Size = new System.Drawing.Size(70, 20);
            this.txbAlimSing5.TabIndex = 42;
            this.txbAlimSing5.Visible = false;
            this.txbAlimSing5.Click += new System.EventHandler(this.txbAlimSing5_Click);
            // 
            // lblAlimSing5
            // 
            this.lblAlimSing5.AutoSize = true;
            this.lblAlimSing5.BackColor = System.Drawing.Color.Transparent;
            this.lblAlimSing5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAlimSing5.Location = new System.Drawing.Point(215, 219);
            this.lblAlimSing5.Name = "lblAlimSing5";
            this.lblAlimSing5.Size = new System.Drawing.Size(87, 13);
            this.lblAlimSing5.TabIndex = 41;
            this.lblAlimSing5.Text = "Singularides 5";
            this.lblAlimSing5.Visible = false;
            // 
            // txbAlimQtd5
            // 
            this.txbAlimQtd5.Location = new System.Drawing.Point(17, 241);
            this.txbAlimQtd5.Name = "txbAlimQtd5";
            this.txbAlimQtd5.Size = new System.Drawing.Size(51, 20);
            this.txbAlimQtd5.TabIndex = 40;
            this.txbAlimQtd5.Visible = false;
            this.txbAlimQtd5.Click += new System.EventHandler(this.txbAlimQtd5_Click);
            // 
            // lblAlimQtd5
            // 
            this.lblAlimQtd5.AutoSize = true;
            this.lblAlimQtd5.BackColor = System.Drawing.Color.Transparent;
            this.lblAlimQtd5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAlimQtd5.Location = new System.Drawing.Point(14, 219);
            this.lblAlimQtd5.Name = "lblAlimQtd5";
            this.lblAlimQtd5.Size = new System.Drawing.Size(174, 13);
            this.lblAlimQtd5.TabIndex = 39;
            this.lblAlimQtd5.Text = "Pontos de Alim. Secundária 5";
            this.lblAlimQtd5.Visible = false;
            // 
            // lblAlimDiaResp4
            // 
            this.lblAlimDiaResp4.AutoSize = true;
            this.lblAlimDiaResp4.BackColor = System.Drawing.Color.Transparent;
            this.lblAlimDiaResp4.Location = new System.Drawing.Point(344, 193);
            this.lblAlimDiaResp4.Name = "lblAlimDiaResp4";
            this.lblAlimDiaResp4.Size = new System.Drawing.Size(22, 13);
            this.lblAlimDiaResp4.TabIndex = 36;
            this.lblAlimDiaResp4.Text = "-----";
            this.lblAlimDiaResp4.Visible = false;
            // 
            // lblAlimDia4
            // 
            this.lblAlimDia4.AutoSize = true;
            this.lblAlimDia4.BackColor = System.Drawing.Color.Transparent;
            this.lblAlimDia4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAlimDia4.Location = new System.Drawing.Point(327, 169);
            this.lblAlimDia4.Name = "lblAlimDia4";
            this.lblAlimDia4.Size = new System.Drawing.Size(57, 13);
            this.lblAlimDia4.TabIndex = 35;
            this.lblAlimDia4.Text = "Diâmetro";
            this.lblAlimDia4.Visible = false;
            // 
            // txbAlimSing4
            // 
            this.txbAlimSing4.Location = new System.Drawing.Point(218, 190);
            this.txbAlimSing4.Name = "txbAlimSing4";
            this.txbAlimSing4.Size = new System.Drawing.Size(70, 20);
            this.txbAlimSing4.TabIndex = 34;
            this.txbAlimSing4.Visible = false;
            this.txbAlimSing4.Click += new System.EventHandler(this.txbAlimSing4_Click);
            // 
            // lblAlimSing4
            // 
            this.lblAlimSing4.AutoSize = true;
            this.lblAlimSing4.BackColor = System.Drawing.Color.Transparent;
            this.lblAlimSing4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAlimSing4.Location = new System.Drawing.Point(215, 168);
            this.lblAlimSing4.Name = "lblAlimSing4";
            this.lblAlimSing4.Size = new System.Drawing.Size(87, 13);
            this.lblAlimSing4.TabIndex = 33;
            this.lblAlimSing4.Text = "Singularides 4";
            this.lblAlimSing4.Visible = false;
            // 
            // txbAlimQtd4
            // 
            this.txbAlimQtd4.Location = new System.Drawing.Point(17, 190);
            this.txbAlimQtd4.Name = "txbAlimQtd4";
            this.txbAlimQtd4.Size = new System.Drawing.Size(51, 20);
            this.txbAlimQtd4.TabIndex = 32;
            this.txbAlimQtd4.Visible = false;
            this.txbAlimQtd4.Click += new System.EventHandler(this.txbAlimQtd4_Click);
            // 
            // lblAlimQtd4
            // 
            this.lblAlimQtd4.AutoSize = true;
            this.lblAlimQtd4.BackColor = System.Drawing.Color.Transparent;
            this.lblAlimQtd4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAlimQtd4.Location = new System.Drawing.Point(14, 168);
            this.lblAlimQtd4.Name = "lblAlimQtd4";
            this.lblAlimQtd4.Size = new System.Drawing.Size(174, 13);
            this.lblAlimQtd4.TabIndex = 31;
            this.lblAlimQtd4.Text = "Pontos de Alim. Secundária 4";
            this.lblAlimQtd4.Visible = false;
            // 
            // lblAlimDiaResp3
            // 
            this.lblAlimDiaResp3.AutoSize = true;
            this.lblAlimDiaResp3.BackColor = System.Drawing.Color.Transparent;
            this.lblAlimDiaResp3.Location = new System.Drawing.Point(344, 142);
            this.lblAlimDiaResp3.Name = "lblAlimDiaResp3";
            this.lblAlimDiaResp3.Size = new System.Drawing.Size(22, 13);
            this.lblAlimDiaResp3.TabIndex = 28;
            this.lblAlimDiaResp3.Text = "-----";
            this.lblAlimDiaResp3.Visible = false;
            // 
            // lblAlimDiaResp2
            // 
            this.lblAlimDiaResp2.AutoSize = true;
            this.lblAlimDiaResp2.BackColor = System.Drawing.Color.Transparent;
            this.lblAlimDiaResp2.Location = new System.Drawing.Point(344, 88);
            this.lblAlimDiaResp2.Name = "lblAlimDiaResp2";
            this.lblAlimDiaResp2.Size = new System.Drawing.Size(22, 13);
            this.lblAlimDiaResp2.TabIndex = 27;
            this.lblAlimDiaResp2.Text = "-----";
            this.lblAlimDiaResp2.Visible = false;
            // 
            // lblAlimDiaResp1
            // 
            this.lblAlimDiaResp1.AutoSize = true;
            this.lblAlimDiaResp1.BackColor = System.Drawing.Color.Transparent;
            this.lblAlimDiaResp1.Location = new System.Drawing.Point(344, 34);
            this.lblAlimDiaResp1.Name = "lblAlimDiaResp1";
            this.lblAlimDiaResp1.Size = new System.Drawing.Size(22, 13);
            this.lblAlimDiaResp1.TabIndex = 26;
            this.lblAlimDiaResp1.Text = "-----";
            // 
            // lblAlimDia3
            // 
            this.lblAlimDia3.AutoSize = true;
            this.lblAlimDia3.BackColor = System.Drawing.Color.Transparent;
            this.lblAlimDia3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAlimDia3.Location = new System.Drawing.Point(327, 115);
            this.lblAlimDia3.Name = "lblAlimDia3";
            this.lblAlimDia3.Size = new System.Drawing.Size(57, 13);
            this.lblAlimDia3.TabIndex = 25;
            this.lblAlimDia3.Text = "Diâmetro";
            this.lblAlimDia3.Visible = false;
            // 
            // txbAlimSing3
            // 
            this.txbAlimSing3.Location = new System.Drawing.Point(218, 139);
            this.txbAlimSing3.Name = "txbAlimSing3";
            this.txbAlimSing3.Size = new System.Drawing.Size(70, 20);
            this.txbAlimSing3.TabIndex = 24;
            this.txbAlimSing3.Visible = false;
            this.txbAlimSing3.Click += new System.EventHandler(this.txbAlimSing3_Click);
            // 
            // lblAlimSing3
            // 
            this.lblAlimSing3.AutoSize = true;
            this.lblAlimSing3.BackColor = System.Drawing.Color.Transparent;
            this.lblAlimSing3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAlimSing3.Location = new System.Drawing.Point(215, 117);
            this.lblAlimSing3.Name = "lblAlimSing3";
            this.lblAlimSing3.Size = new System.Drawing.Size(87, 13);
            this.lblAlimSing3.TabIndex = 23;
            this.lblAlimSing3.Text = "Singularides 3";
            this.lblAlimSing3.Visible = false;
            // 
            // txbAlimQtd3
            // 
            this.txbAlimQtd3.Location = new System.Drawing.Point(17, 139);
            this.txbAlimQtd3.Name = "txbAlimQtd3";
            this.txbAlimQtd3.Size = new System.Drawing.Size(51, 20);
            this.txbAlimQtd3.TabIndex = 22;
            this.txbAlimQtd3.Visible = false;
            this.txbAlimQtd3.Click += new System.EventHandler(this.txbAlimQtd3_Click);
            // 
            // lblAlimQtd3
            // 
            this.lblAlimQtd3.AutoSize = true;
            this.lblAlimQtd3.BackColor = System.Drawing.Color.Transparent;
            this.lblAlimQtd3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAlimQtd3.Location = new System.Drawing.Point(14, 117);
            this.lblAlimQtd3.Name = "lblAlimQtd3";
            this.lblAlimQtd3.Size = new System.Drawing.Size(174, 13);
            this.lblAlimQtd3.TabIndex = 21;
            this.lblAlimQtd3.Text = "Pontos de Alim. Secundária 3";
            this.lblAlimQtd3.Visible = false;
            // 
            // lblAlimDia2
            // 
            this.lblAlimDia2.AutoSize = true;
            this.lblAlimDia2.BackColor = System.Drawing.Color.Transparent;
            this.lblAlimDia2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAlimDia2.Location = new System.Drawing.Point(327, 61);
            this.lblAlimDia2.Name = "lblAlimDia2";
            this.lblAlimDia2.Size = new System.Drawing.Size(57, 13);
            this.lblAlimDia2.TabIndex = 19;
            this.lblAlimDia2.Text = "Diâmetro";
            this.lblAlimDia2.Visible = false;
            // 
            // txbAlimSing2
            // 
            this.txbAlimSing2.Location = new System.Drawing.Point(218, 86);
            this.txbAlimSing2.Name = "txbAlimSing2";
            this.txbAlimSing2.Size = new System.Drawing.Size(70, 20);
            this.txbAlimSing2.TabIndex = 18;
            this.txbAlimSing2.Visible = false;
            this.txbAlimSing2.Click += new System.EventHandler(this.txbAlimSing2_Click);
            // 
            // lblAlimSing2
            // 
            this.lblAlimSing2.AutoSize = true;
            this.lblAlimSing2.BackColor = System.Drawing.Color.Transparent;
            this.lblAlimSing2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAlimSing2.Location = new System.Drawing.Point(215, 62);
            this.lblAlimSing2.Name = "lblAlimSing2";
            this.lblAlimSing2.Size = new System.Drawing.Size(87, 13);
            this.lblAlimSing2.TabIndex = 17;
            this.lblAlimSing2.Text = "Singularides 2";
            this.lblAlimSing2.Visible = false;
            // 
            // txbAlimQtd2
            // 
            this.txbAlimQtd2.Location = new System.Drawing.Point(17, 86);
            this.txbAlimQtd2.Name = "txbAlimQtd2";
            this.txbAlimQtd2.Size = new System.Drawing.Size(51, 20);
            this.txbAlimQtd2.TabIndex = 16;
            this.txbAlimQtd2.Visible = false;
            this.txbAlimQtd2.Click += new System.EventHandler(this.txbAlimQtd2_Click);
            // 
            // lblAlimQtd2
            // 
            this.lblAlimQtd2.AutoSize = true;
            this.lblAlimQtd2.BackColor = System.Drawing.Color.Transparent;
            this.lblAlimQtd2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAlimQtd2.Location = new System.Drawing.Point(14, 62);
            this.lblAlimQtd2.Name = "lblAlimQtd2";
            this.lblAlimQtd2.Size = new System.Drawing.Size(174, 13);
            this.lblAlimQtd2.TabIndex = 15;
            this.lblAlimQtd2.Text = "Pontos de Alim. Secundária 2";
            this.lblAlimQtd2.Visible = false;
            // 
            // lblAlimDia1
            // 
            this.lblAlimDia1.AutoSize = true;
            this.lblAlimDia1.BackColor = System.Drawing.Color.Transparent;
            this.lblAlimDia1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAlimDia1.Location = new System.Drawing.Point(327, 7);
            this.lblAlimDia1.Name = "lblAlimDia1";
            this.lblAlimDia1.Size = new System.Drawing.Size(57, 13);
            this.lblAlimDia1.TabIndex = 13;
            this.lblAlimDia1.Text = "Diâmetro";
            // 
            // txbAlimSing1
            // 
            this.txbAlimSing1.Location = new System.Drawing.Point(218, 31);
            this.txbAlimSing1.Name = "txbAlimSing1";
            this.txbAlimSing1.Size = new System.Drawing.Size(70, 20);
            this.txbAlimSing1.TabIndex = 12;
            this.txbAlimSing1.Click += new System.EventHandler(this.txbAlimSing1_Click);
            // 
            // lblAlimSing1
            // 
            this.lblAlimSing1.AutoSize = true;
            this.lblAlimSing1.BackColor = System.Drawing.Color.Transparent;
            this.lblAlimSing1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAlimSing1.Location = new System.Drawing.Point(215, 7);
            this.lblAlimSing1.Name = "lblAlimSing1";
            this.lblAlimSing1.Size = new System.Drawing.Size(87, 13);
            this.lblAlimSing1.TabIndex = 11;
            this.lblAlimSing1.Text = "Singularides 1";
            // 
            // lblAlimQtd1
            // 
            this.lblAlimQtd1.AutoSize = true;
            this.lblAlimQtd1.BackColor = System.Drawing.Color.Transparent;
            this.lblAlimQtd1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAlimQtd1.Location = new System.Drawing.Point(14, 7);
            this.lblAlimQtd1.Name = "lblAlimQtd1";
            this.lblAlimQtd1.Size = new System.Drawing.Size(174, 13);
            this.lblAlimQtd1.TabIndex = 1;
            this.lblAlimQtd1.Text = "Pontos de Alim. Secundária 1";
            // 
            // txbAlimQtd1
            // 
            this.txbAlimQtd1.Location = new System.Drawing.Point(17, 31);
            this.txbAlimQtd1.Name = "txbAlimQtd1";
            this.txbAlimQtd1.Size = new System.Drawing.Size(51, 20);
            this.txbAlimQtd1.TabIndex = 3;
            this.txbAlimQtd1.Click += new System.EventHandler(this.txbAlimQtd1_Click);
            // 
            // btnCalcAlim
            // 
            this.btnCalcAlim.BackColor = System.Drawing.Color.Transparent;
            this.btnCalcAlim.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnCalcAlim.FlatAppearance.BorderSize = 0;
            this.btnCalcAlim.FlatAppearance.MouseDownBackColor = System.Drawing.SystemColors.Highlight;
            this.btnCalcAlim.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnCalcAlim.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCalcAlim.Image = ((System.Drawing.Image)(resources.GetObject("btnCalcAlim.Image")));
            this.btnCalcAlim.Location = new System.Drawing.Point(442, 174);
            this.btnCalcAlim.Name = "btnCalcAlim";
            this.btnCalcAlim.Size = new System.Drawing.Size(194, 41);
            this.btnCalcAlim.TabIndex = 46;
            this.btnCalcAlim.UseVisualStyleBackColor = false;
            this.btnCalcAlim.Click += new System.EventHandler(this.btnCalcAlim_Click);
            // 
            // btnTabela2
            // 
            this.btnTabela2.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btnTabela2.BackColor = System.Drawing.Color.Transparent;
            this.btnTabela2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnTabela2.BackgroundImage")));
            this.btnTabela2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnTabela2.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnTabela2.FlatAppearance.BorderSize = 0;
            this.btnTabela2.FlatAppearance.MouseDownBackColor = System.Drawing.SystemColors.Highlight;
            this.btnTabela2.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnTabela2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTabela2.Location = new System.Drawing.Point(22, 425);
            this.btnTabela2.Name = "btnTabela2";
            this.btnTabela2.Size = new System.Drawing.Size(175, 35);
            this.btnTabela2.TabIndex = 47;
            this.btnTabela2.UseVisualStyleBackColor = false;
            this.btnTabela2.Click += new System.EventHandler(this.btnTabela2_Click);
            // 
            // lblInfo
            // 
            this.lblInfo.AutoSize = true;
            this.lblInfo.BackColor = System.Drawing.Color.DarkOrange;
            this.lblInfo.Location = new System.Drawing.Point(233, 449);
            this.lblInfo.Name = "lblInfo";
            this.lblInfo.Size = new System.Drawing.Size(378, 13);
            this.lblInfo.TabIndex = 48;
            this.lblInfo.Text = "Ordem de cálculo: Linha principal -> Linha Secundária -> Linha de alimentação";
            // 
            // Dimensionamento_Linha
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(695, 485);
            this.Controls.Add(this.lblInfo);
            this.Controls.Add(this.btnTabela2);
            this.Controls.Add(this.btnCalcAlim);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.btnCalcSec);
            this.Controls.Add(this.btnLinhaSecDel);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.lblPriRes);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.btnCalc1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnLinhaSecAdd);
            this.Controls.Add(this.panel1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "Dimensionamento_Linha";
            this.Text = "Linhas";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox txbAuCap;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txbPress;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txbPerda;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txbComp;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txbVaz;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnCalc1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label lblPriRes;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label lblSecComp2;
        private System.Windows.Forms.TextBox txbSecComp3;
        private System.Windows.Forms.TextBox txbSecComp2;
        private System.Windows.Forms.Label lblSecComp3;
        private System.Windows.Forms.TextBox txbSecComp1;
        private System.Windows.Forms.Label lblSecQtd1;
        private System.Windows.Forms.TextBox txbSecQtd1;
        private System.Windows.Forms.Label lblSecComp1;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label lblSecDia2;
        private System.Windows.Forms.TextBox txbSecSing2;
        private System.Windows.Forms.Label lblSecSing2;
        private System.Windows.Forms.TextBox txbSecQtd2;
        private System.Windows.Forms.Label lblSecQtd2;
        private System.Windows.Forms.Label lblSecDia1;
        private System.Windows.Forms.TextBox txbSecSing1;
        private System.Windows.Forms.Label lblSecSing1;
        private System.Windows.Forms.Label lblSecDia3;
        private System.Windows.Forms.TextBox txbSecSing3;
        private System.Windows.Forms.Label lblSecSing3;
        private System.Windows.Forms.TextBox txbSecQtd3;
        private System.Windows.Forms.Label lblSecQtd3;
        private System.Windows.Forms.Label lblSecDiaResp3;
        private System.Windows.Forms.Label lblSecDiaResp2;
        private System.Windows.Forms.Label lblSecDiaResp1;
        private System.Windows.Forms.Button btnLinhaSecAdd;
        private System.Windows.Forms.Label lblSecDiaResp4;
        private System.Windows.Forms.Label lblSecDia4;
        private System.Windows.Forms.TextBox txbSecSing4;
        private System.Windows.Forms.Label lblSecSing4;
        private System.Windows.Forms.TextBox txbSecQtd4;
        private System.Windows.Forms.Label lblSecQtd4;
        private System.Windows.Forms.TextBox txbSecComp4;
        private System.Windows.Forms.Label lblSecComp4;
        private System.Windows.Forms.Label lblSecDiaResp5;
        private System.Windows.Forms.Label lblSecDia5;
        private System.Windows.Forms.TextBox txbSecSing5;
        private System.Windows.Forms.Label lblSecSing5;
        private System.Windows.Forms.TextBox txbSecQtd5;
        private System.Windows.Forms.Label lblSecQtd5;
        private System.Windows.Forms.TextBox txbSecComp5;
        private System.Windows.Forms.Label lblSecComp5;
        private System.Windows.Forms.Button btnLinhaSecDel;
        private System.Windows.Forms.TextBox txbPriCompSingu;
        private System.Windows.Forms.Label lblPriCompSing;
        private System.Windows.Forms.Button btnCalcSec;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label lblAlimDiaResp5;
        private System.Windows.Forms.Label lblAlimDia5;
        private System.Windows.Forms.TextBox txbAlimSing5;
        private System.Windows.Forms.Label lblAlimSing5;
        private System.Windows.Forms.TextBox txbAlimQtd5;
        private System.Windows.Forms.Label lblAlimQtd5;
        private System.Windows.Forms.Label lblAlimDiaResp4;
        private System.Windows.Forms.Label lblAlimDia4;
        private System.Windows.Forms.TextBox txbAlimSing4;
        private System.Windows.Forms.Label lblAlimSing4;
        private System.Windows.Forms.TextBox txbAlimQtd4;
        private System.Windows.Forms.Label lblAlimQtd4;
        private System.Windows.Forms.Label lblAlimDiaResp3;
        private System.Windows.Forms.Label lblAlimDiaResp2;
        private System.Windows.Forms.Label lblAlimDiaResp1;
        private System.Windows.Forms.Label lblAlimDia3;
        private System.Windows.Forms.TextBox txbAlimSing3;
        private System.Windows.Forms.Label lblAlimSing3;
        private System.Windows.Forms.TextBox txbAlimQtd3;
        private System.Windows.Forms.Label lblAlimQtd3;
        private System.Windows.Forms.Label lblAlimDia2;
        private System.Windows.Forms.TextBox txbAlimSing2;
        private System.Windows.Forms.Label lblAlimSing2;
        private System.Windows.Forms.TextBox txbAlimQtd2;
        private System.Windows.Forms.Label lblAlimQtd2;
        private System.Windows.Forms.Label lblAlimDia1;
        private System.Windows.Forms.TextBox txbAlimSing1;
        private System.Windows.Forms.Label lblAlimSing1;
        private System.Windows.Forms.Label lblAlimQtd1;
        private System.Windows.Forms.TextBox txbAlimQtd1;
        private System.Windows.Forms.Button btnCalcAlim;
        private System.Windows.Forms.Button btnTabela2;
        private System.Windows.Forms.Label lblInfo;
    }
}